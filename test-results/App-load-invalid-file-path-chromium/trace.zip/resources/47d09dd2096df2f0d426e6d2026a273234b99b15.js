import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f35b47c0"; const useState = __vite__cjsImport3_react["useState"];
import "/src/styles/main.css";
import { REPLHistory } from "/src/components/REPLHistory.tsx";
import { REPLInput } from "/src/components/REPLInput.tsx";
export default function REPL() {
  _s();
  const [history, setHistory] = useState([]);
  const [mode, setMode] = useState("brief");
  const [hasHeader, setHasHeader] = useState(true);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { history, mode }, void 0, false, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPLInput, { history, setHistory, mode, setMode }, void 0, false, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx",
      lineNumber: 29,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
}
_s(REPL, "CMbW7+WU5dKujAzUV426mMLe69o=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCTixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBTztBQUNQLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxpQkFBaUI7QUFXMUIsd0JBQXdCQyxPQUFPO0FBQUFDLEtBQUE7QUFFN0IsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlOLFNBRTVCLEVBQUU7QUFDSixRQUFNLENBQUNPLE1BQU1DLE9BQU8sSUFBSVIsU0FBaUIsT0FBTztBQUNoRCxRQUFNLENBQUNTLFdBQVdDLFlBQVksSUFBSVYsU0FBa0IsSUFBSTtBQUV4RCxTQUNFLHVCQUFDLFNBQUksV0FBVSxRQUliO0FBQUEsMkJBQUMsZUFBWSxTQUFrQixRQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDO0FBQUEsSUFDMUMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUk7QUFBQSxJQUVKLHVCQUFDLGFBQ0MsU0FDQSxZQUNBLE1BQ0EsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSW1CO0FBQUEsT0FYckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7QUFBQ0ksR0F4QnVCRCxNQUFJO0FBQUFRLEtBQUpSO0FBQUksSUFBQVE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiUkVQTEhpc3RvcnkiLCJSRVBMSW5wdXQiLCJSRVBMIiwiX3MiLCJoaXN0b3J5Iiwic2V0SGlzdG9yeSIsIm1vZGUiLCJzZXRNb2RlIiwiaGFzSGVhZGVyIiwic2V0SGFzSGVhZGVyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBSRVBMSGlzdG9yeSB9IGZyb20gXCIuL1JFUExIaXN0b3J5XCI7XG5pbXBvcnQgeyBSRVBMSW5wdXQgfSBmcm9tIFwiLi9SRVBMSW5wdXRcIjtcblxuLyogXG4gIFlvdSdsbCB3YW50IHRvIGV4cGFuZCB0aGlzIGNvbXBvbmVudCAoYW5kIG90aGVycykgZm9yIHRoZSBzcHJpbnRzISBSZW1lbWJlciBcbiAgdGhhdCB5b3UgY2FuIHBhc3MgXCJwcm9wc1wiIGFzIGZ1bmN0aW9uIGFyZ3VtZW50cy4gSWYgeW91IG5lZWQgdG8gaGFuZGxlIHN0YXRlIFxuICBhdCBhIGhpZ2hlciBsZXZlbCwganVzdCBtb3ZlIHVwIHRoZSBob29rcyBhbmQgcGFzcyB0aGUgc3RhdGUvc2V0dGVyIGFzIGEgcHJvcC5cbiAgXG4gIFRoaXMgaXMgYSBncmVhdCB0b3AgbGV2ZWwgY29tcG9uZW50IGZvciB0aGUgUkVQTC4gSXQncyBhIGdvb2QgaWRlYSB0byBoYXZlIG9yZ2FuaXplIGFsbCBjb21wb25lbnRzIGluIGEgY29tcG9uZW50IGZvbGRlci5cbiAgWW91IGRvbid0IG5lZWQgdG8gZG8gdGhhdCBmb3IgdGhpcyBnZWFydXAuXG4qL1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSRVBMKCkge1xuICAvLyBUT0RPOiBBZGQgc29tZSBraW5kIG9mIHNoYXJlZCBzdGF0ZSB0aGF0IGhvbGRzIGFsbCB0aGUgY29tbWFuZHMgc3VibWl0dGVkLlxuICBjb25zdCBbaGlzdG9yeSwgc2V0SGlzdG9yeV0gPSB1c2VTdGF0ZTxcbiAgICBbc3RyaW5nLCBzdHJpbmdbXVtdIHwgc3RyaW5nLCBzdHJpbmddW11cbiAgPihbXSk7XG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJicmllZlwiKTtcbiAgY29uc3QgW2hhc0hlYWRlciwgc2V0SGFzSGVhZGVyXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsXCI+XG4gICAgICB7LypUaGlzIGlzIHdoZXJlIHlvdXIgUkVQTEhpc3RvcnkgbWlnaHQgZ28uLi4gWW91IGFsc28gbWF5IGNob29zZSB0byBhZGQgaXQgd2l0aGluIHlvdXIgUkVQTElucHV0IFxuICAgICAgY29tcG9uZW50IG9yIHNvbWV3aGVyZSBlbHNlIGRlcGVuZGluZyBvbiB5b3VyIGNvbXBvbmVudCBvcmdhbml6YXRpb24uIFdoYXQgYXJlIHRoZSBwcm9zIGFuZCBjb25zIG9mIGVhY2g/ICovfVxuICAgICAgey8qIENIQU5HRUQgKi99XG4gICAgICA8UkVQTEhpc3RvcnkgaGlzdG9yeT17aGlzdG9yeX0gbW9kZT17bW9kZX0gLz5cbiAgICAgIDxocj48L2hyPlxuICAgICAgey8qIENIQU5HRUQgKi99XG4gICAgICA8UkVQTElucHV0XG4gICAgICAgIGhpc3Rvcnk9e2hpc3Rvcnl9XG4gICAgICAgIHNldEhpc3Rvcnk9e3NldEhpc3Rvcnl9XG4gICAgICAgIG1vZGU9e21vZGV9XG4gICAgICAgIHNldE1vZGU9e3NldE1vZGV9XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvMjFrZW5uL0Rlc2t0b3AvY3MwMzIwL21vY2stdG5nYW1wcmEtd2NoeXVuL3NyYy9jb21wb25lbnRzL1JFUEwudHN4In0=