import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f35b47c0"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import all_data from "/src/mocked-data/mockedJson.ts";
var data = all_data["data"];
var searchData = all_data["search_data"];
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [loadedFilepath, setloadedFilepath] = useState("");
  const [hasLoaded, setHasLoaded] = useState(false);
  function handleSubmit(commandString2) {
    var splitted = commandString2.split(" ");
    var command = splitted[0];
    var output;
    if (command == "mode") {
      if (splitted.length == 1) {
        props.mode === "brief" ? props.setMode("verbose") : props.setMode("brief");
        output = "Successfully changed mode";
      } else {
        output = "Wrong number of arguments for mode command";
      }
    } else if (command == "load_file") {
      if (splitted.length == 2) {
        var filepath = splitted[1];
        if (filepath in data) {
          output = "File successfully loaded";
          console.log(filepath);
          setloadedFilepath(filepath);
          setHasLoaded(true);
        } else {
          output = "File not found in directory";
        }
      } else {
        output = "Wrong number of arguments for load command";
      }
    } else if (command == "view") {
      if (hasLoaded) {
        if (splitted.length == 1) {
          output = loadedFilepath in data ? data[loadedFilepath] : "File not found in directory";
        } else {
          output = "Wrong number of arguments for view command";
        }
      } else {
        output = "Cannot call view before load";
      }
    } else if (command == "search") {
      if (hasLoaded) {
        if (splitted.length == 3) {
          var column = splitted[1];
          var value = splitted[2];
          var key = [column, value];
          if (loadedFilepath in searchData) {
            var filepath_commands = searchData[loadedFilepath];
            output = JSON.stringify(key) in filepath_commands ? filepath_commands[JSON.stringify(key)] : "Command does not exist in mocked search data";
          } else {
            output = "File not found in directory";
          }
        } else {
          output = "Wrong number of arguments for search command";
        }
      } else {
        output = "Cannot call search before load";
      }
    } else {
      output = "Not a valid command";
    }
    if (typeof output == "undefined") {
      output = "Not a valid command";
    }
    props.setHistory([...props.history, [command, output, props.mode]]);
    setCount(count + 1);
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
        lineNumber: 106,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
      lineNumber: 104,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: "Submit" }, void 0, false, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
    lineNumber: 99,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "Wd0Zuds1vl8hqfXy0qgHPp/1zxM=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUhROzs7Ozs7Ozs7Ozs7Ozs7OztBQXpIUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsT0FBT0MsY0FBYztBQUVyQixJQUFJQyxPQUFPRCxTQUFTLE1BQU07QUFDMUIsSUFBSUUsYUFBYUYsU0FBUyxhQUFhO0FBYWhDLGdCQUFTRyxVQUFVQyxPQUF1QjtBQUFBQyxLQUFBO0FBRy9DLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUlULFNBQWlCLEVBQUU7QUFFN0QsUUFBTSxDQUFDVSxPQUFPQyxRQUFRLElBQUlYLFNBQWlCLENBQUM7QUFFNUMsUUFBTSxDQUFDWSxnQkFBZ0JDLGlCQUFpQixJQUFJYixTQUFpQixFQUFFO0FBRS9ELFFBQU0sQ0FBQ2MsV0FBV0MsWUFBWSxJQUFJZixTQUFrQixLQUFLO0FBR3pELFdBQVNnQixhQUFhUixnQkFBdUI7QUFDM0MsUUFBSVMsV0FBV1QsZUFBY1UsTUFBTSxHQUFHO0FBQ3RDLFFBQUlDLFVBQVVGLFNBQVMsQ0FBQztBQUN4QixRQUFJRztBQUVKLFFBQUlELFdBQVcsUUFBUTtBQUNyQixVQUFJRixTQUFTSSxVQUFVLEdBQUc7QUFDeEJmLGNBQU1nQixTQUFTLFVBQ1hoQixNQUFNaUIsUUFBUSxTQUFTLElBQ3ZCakIsTUFBTWlCLFFBQVEsT0FBTztBQUN6QkgsaUJBQVM7QUFBQSxNQUNYLE9BQU87QUFDTEEsaUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRixXQUFXRCxXQUFXLGFBQWE7QUFFakMsVUFBSUYsU0FBU0ksVUFBVSxHQUFHO0FBQ3hCLFlBQUlHLFdBQVdQLFNBQVMsQ0FBQztBQUN6QixZQUFJTyxZQUFZckIsTUFBTTtBQUNwQmlCLG1CQUFTO0FBQ1RLLGtCQUFRQyxJQUFJRixRQUFRO0FBQ3BCWCw0QkFBa0JXLFFBQVE7QUFDMUJULHVCQUFhLElBQUk7QUFBQSxRQUNuQixPQUFPO0FBQ0xLLG1CQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0YsT0FBTztBQUNMQSxpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGLFdBQVdELFdBQVcsUUFBUTtBQUM1QixVQUFJTCxXQUFXO0FBQ2IsWUFBSUcsU0FBU0ksVUFBVSxHQUFHO0FBQ3hCRCxtQkFDRVIsa0JBQWtCVCxPQUNkQSxLQUFLUyxjQUFjLElBQ25CO0FBQUEsUUFDUixPQUFPO0FBQ0xRLG1CQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0YsT0FBTztBQUNMQSxpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGLFdBQVdELFdBQVcsVUFBVTtBQUM5QixVQUFJTCxXQUFXO0FBQ2IsWUFBSUcsU0FBU0ksVUFBVSxHQUFHO0FBRXhCLGNBQUlNLFNBQVNWLFNBQVMsQ0FBQztBQUN2QixjQUFJVyxRQUFRWCxTQUFTLENBQUM7QUFDdEIsY0FBSVksTUFBTSxDQUFDRixRQUFRQyxLQUFLO0FBRXhCLGNBQUloQixrQkFBa0JSLFlBQVk7QUFDaEMsZ0JBQUkwQixvQkFBb0IxQixXQUFXUSxjQUFjO0FBQ2pEUSxxQkFDRVcsS0FBS0MsVUFBVUgsR0FBRyxLQUFLQyxvQkFDbkJBLGtCQUFrQkMsS0FBS0MsVUFBVUgsR0FBRyxDQUFDLElBQ3JDO0FBQUEsVUFDUixPQUFPO0FBQ0xULHFCQUFTO0FBQUEsVUFDWDtBQUFBLFFBQ0YsT0FBTztBQUNMQSxtQkFBUztBQUFBLFFBQ1g7QUFBQSxNQUNGLE9BQU87QUFDTEEsaUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRixPQUFPO0FBQ0xBLGVBQVM7QUFBQSxJQUNYO0FBRUEsUUFBSSxPQUFPQSxVQUFVLGFBQWE7QUFDaENBLGVBQVM7QUFBQSxJQUNYO0FBRUFkLFVBQU0yQixXQUFXLENBQUMsR0FBRzNCLE1BQU00QixTQUFTLENBQUNmLFNBQVNDLFFBQVFkLE1BQU1nQixJQUFJLENBQUMsQ0FBQztBQUVsRVgsYUFBU0QsUUFBUSxDQUFDO0FBRWxCRCxxQkFBaUIsRUFBRTtBQUFBLEVBQ3JCO0FBS0EsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FLYjtBQUFBLDJCQUFDLGNBQ0M7QUFBQSw2QkFBQyxZQUFPLGdDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxtQkFDQyxPQUFPRCxlQUNQLFVBQVVDLGtCQUNWLFdBQVcsbUJBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUc2QjtBQUFBLFNBTC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUEsdUJBQUMsWUFBTyxTQUFTLE1BQU1PLGFBQWFSLGFBQWEsR0FBRyxzQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRDtBQUFBLE9BZDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQTtBQUVKO0FBQUNELEdBakhlRixXQUFTO0FBQUE4QixLQUFUOUI7QUFBUyxJQUFBOEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwiYWxsX2RhdGEiLCJkYXRhIiwic2VhcmNoRGF0YSIsIlJFUExJbnB1dCIsInByb3BzIiwiX3MiLCJjb21tYW5kU3RyaW5nIiwic2V0Q29tbWFuZFN0cmluZyIsImNvdW50Iiwic2V0Q291bnQiLCJsb2FkZWRGaWxlcGF0aCIsInNldGxvYWRlZEZpbGVwYXRoIiwiaGFzTG9hZGVkIiwic2V0SGFzTG9hZGVkIiwiaGFuZGxlU3VibWl0Iiwic3BsaXR0ZWQiLCJzcGxpdCIsImNvbW1hbmQiLCJvdXRwdXQiLCJsZW5ndGgiLCJtb2RlIiwic2V0TW9kZSIsImZpbGVwYXRoIiwiY29uc29sZSIsImxvZyIsImNvbHVtbiIsInZhbHVlIiwia2V5IiwiZmlsZXBhdGhfY29tbWFuZHMiLCJKU09OIiwic3RyaW5naWZ5Iiwic2V0SGlzdG9yeSIsImhpc3RvcnkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9Db250cm9sbGVkSW5wdXRcIjtcbmltcG9ydCBhbGxfZGF0YSBmcm9tIFwiLi4vbW9ja2VkLWRhdGEvbW9ja2VkSnNvblwiO1xuXG52YXIgZGF0YSA9IGFsbF9kYXRhW1wiZGF0YVwiXTtcbnZhciBzZWFyY2hEYXRhID0gYWxsX2RhdGFbXCJzZWFyY2hfZGF0YVwiXTtcblxuaW50ZXJmYWNlIFJFUExJbnB1dFByb3BzIHtcbiAgLy8gVE9ETzogRmlsbCB0aGlzIHdpdGggZGVzaXJlZCBwcm9wcy4uLiBNYXliZSBzb21ldGhpbmcgdG8ga2VlcCB0cmFjayBvZiB0aGUgc3VibWl0dGVkIGNvbW1hbmRzXG4gIC8vIENIQU5HRURcbiAgaGlzdG9yeTogW3N0cmluZywgc3RyaW5nW11bXSB8IHN0cmluZywgc3RyaW5nXVtdO1xuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxbc3RyaW5nLCBzdHJpbmcgfCBzdHJpbmdbXVtdLCBzdHJpbmddW10+PjtcbiAgbW9kZTogc3RyaW5nO1xuICBzZXRNb2RlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+Pjtcbn1cblxuLy8gWW91IGNhbiB1c2UgYSBjdXN0b20gaW50ZXJmYWNlIG9yIGV4cGxpY2l0IGZpZWxkcyBvciBib3RoISBBbiBhbHRlcm5hdGl2ZSB0byB0aGUgY3VycmVudCBmdW5jdGlvbiBoZWFkZXIgbWlnaHQgYmU6XG4vLyBSRVBMSW5wdXQoaGlzdG9yeTogc3RyaW5nW10sIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj4pXG5leHBvcnQgZnVuY3Rpb24gUkVQTElucHV0KHByb3BzOiBSRVBMSW5wdXRQcm9wcykge1xuICAvLyBSZW1lbWJlcjogbGV0IFJlYWN0IG1hbmFnZSBzdGF0ZSBpbiB5b3VyIHdlYmFwcC5cbiAgLy8gTWFuYWdlcyB0aGUgY29udGVudHMgb2YgdGhlIGlucHV0IGJveFxuICBjb25zdCBbY29tbWFuZFN0cmluZywgc2V0Q29tbWFuZFN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuICAvLyBNYW5hZ2VzIHRoZSBjdXJyZW50IGFtb3VudCBvZiB0aW1lcyB0aGUgYnV0dG9uIGlzIGNsaWNrZWRcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuXG4gIGNvbnN0IFtsb2FkZWRGaWxlcGF0aCwgc2V0bG9hZGVkRmlsZXBhdGhdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcblxuICBjb25zdCBbaGFzTG9hZGVkLCBzZXRIYXNMb2FkZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuXG4gIC8vIFRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIHdoZW4gdGhlIGJ1dHRvbiBpcyBjbGlja2VkLlxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XG4gICAgdmFyIHNwbGl0dGVkID0gY29tbWFuZFN0cmluZy5zcGxpdChcIiBcIik7XG4gICAgdmFyIGNvbW1hbmQgPSBzcGxpdHRlZFswXTtcbiAgICB2YXIgb3V0cHV0O1xuXG4gICAgaWYgKGNvbW1hbmQgPT0gXCJtb2RlXCIpIHtcbiAgICAgIGlmIChzcGxpdHRlZC5sZW5ndGggPT0gMSkge1xuICAgICAgICBwcm9wcy5tb2RlID09PSBcImJyaWVmXCJcbiAgICAgICAgICA/IHByb3BzLnNldE1vZGUoXCJ2ZXJib3NlXCIpXG4gICAgICAgICAgOiBwcm9wcy5zZXRNb2RlKFwiYnJpZWZcIik7XG4gICAgICAgIG91dHB1dCA9IFwiU3VjY2Vzc2Z1bGx5IGNoYW5nZWQgbW9kZVwiO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb3V0cHV0ID0gXCJXcm9uZyBudW1iZXIgb2YgYXJndW1lbnRzIGZvciBtb2RlIGNvbW1hbmRcIjtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNvbW1hbmQgPT0gXCJsb2FkX2ZpbGVcIikge1xuICAgICAgLy9UT0RPIEhBTkRMRSBIRUFERVJcbiAgICAgIGlmIChzcGxpdHRlZC5sZW5ndGggPT0gMikge1xuICAgICAgICB2YXIgZmlsZXBhdGggPSBzcGxpdHRlZFsxXTtcbiAgICAgICAgaWYgKGZpbGVwYXRoIGluIGRhdGEpIHtcbiAgICAgICAgICBvdXRwdXQgPSBcIkZpbGUgc3VjY2Vzc2Z1bGx5IGxvYWRlZFwiO1xuICAgICAgICAgIGNvbnNvbGUubG9nKGZpbGVwYXRoKTtcbiAgICAgICAgICBzZXRsb2FkZWRGaWxlcGF0aChmaWxlcGF0aCk7XG4gICAgICAgICAgc2V0SGFzTG9hZGVkKHRydWUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG91dHB1dCA9IFwiRmlsZSBub3QgZm91bmQgaW4gZGlyZWN0b3J5XCI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG91dHB1dCA9IFwiV3JvbmcgbnVtYmVyIG9mIGFyZ3VtZW50cyBmb3IgbG9hZCBjb21tYW5kXCI7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChjb21tYW5kID09IFwidmlld1wiKSB7XG4gICAgICBpZiAoaGFzTG9hZGVkKSB7XG4gICAgICAgIGlmIChzcGxpdHRlZC5sZW5ndGggPT0gMSkge1xuICAgICAgICAgIG91dHB1dCA9XG4gICAgICAgICAgICBsb2FkZWRGaWxlcGF0aCBpbiBkYXRhXG4gICAgICAgICAgICAgID8gZGF0YVtsb2FkZWRGaWxlcGF0aF1cbiAgICAgICAgICAgICAgOiBcIkZpbGUgbm90IGZvdW5kIGluIGRpcmVjdG9yeVwiO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG91dHB1dCA9IFwiV3JvbmcgbnVtYmVyIG9mIGFyZ3VtZW50cyBmb3IgdmlldyBjb21tYW5kXCI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG91dHB1dCA9IFwiQ2Fubm90IGNhbGwgdmlldyBiZWZvcmUgbG9hZFwiO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PSBcInNlYXJjaFwiKSB7XG4gICAgICBpZiAoaGFzTG9hZGVkKSB7XG4gICAgICAgIGlmIChzcGxpdHRlZC5sZW5ndGggPT0gMykge1xuICAgICAgICAgIC8vIEhPVyBUTyBERUFMIFdJVEggU1BBQ0VTIElOIElOUFVUXG4gICAgICAgICAgdmFyIGNvbHVtbiA9IHNwbGl0dGVkWzFdO1xuICAgICAgICAgIHZhciB2YWx1ZSA9IHNwbGl0dGVkWzJdO1xuICAgICAgICAgIHZhciBrZXkgPSBbY29sdW1uLCB2YWx1ZV07XG5cbiAgICAgICAgICBpZiAobG9hZGVkRmlsZXBhdGggaW4gc2VhcmNoRGF0YSkge1xuICAgICAgICAgICAgdmFyIGZpbGVwYXRoX2NvbW1hbmRzID0gc2VhcmNoRGF0YVtsb2FkZWRGaWxlcGF0aF07XG4gICAgICAgICAgICBvdXRwdXQgPVxuICAgICAgICAgICAgICBKU09OLnN0cmluZ2lmeShrZXkpIGluIGZpbGVwYXRoX2NvbW1hbmRzXG4gICAgICAgICAgICAgICAgPyBmaWxlcGF0aF9jb21tYW5kc1tKU09OLnN0cmluZ2lmeShrZXkpXVxuICAgICAgICAgICAgICAgIDogXCJDb21tYW5kIGRvZXMgbm90IGV4aXN0IGluIG1vY2tlZCBzZWFyY2ggZGF0YVwiO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBvdXRwdXQgPSBcIkZpbGUgbm90IGZvdW5kIGluIGRpcmVjdG9yeVwiO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvdXRwdXQgPSBcIldyb25nIG51bWJlciBvZiBhcmd1bWVudHMgZm9yIHNlYXJjaCBjb21tYW5kXCI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG91dHB1dCA9IFwiQ2Fubm90IGNhbGwgc2VhcmNoIGJlZm9yZSBsb2FkXCI7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIG91dHB1dCA9IFwiTm90IGEgdmFsaWQgY29tbWFuZFwiO1xuICAgIH1cblxuICAgIGlmICh0eXBlb2Ygb3V0cHV0ID09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIG91dHB1dCA9IFwiTm90IGEgdmFsaWQgY29tbWFuZFwiO1xuICAgIH1cblxuICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmhpc3RvcnksIFtjb21tYW5kLCBvdXRwdXQsIHByb3BzLm1vZGVdXSk7XG5cbiAgICBzZXRDb3VudChjb3VudCArIDEpO1xuXG4gICAgc2V0Q29tbWFuZFN0cmluZyhcIlwiKTtcbiAgfVxuICAvKipcbiAgICogV2Ugc3VnZ2VzdCBicmVha2luZyBkb3duIHRoaXMgY29tcG9uZW50IGludG8gc21hbGxlciBjb21wb25lbnRzLCB0aGluayBhYm91dCB0aGUgaW5kaXZpZHVhbCBwaWVjZXNcbiAgICogb2YgdGhlIFJFUEwgYW5kIGhvdyB0aGV5IGNvbm5lY3QgdG8gZWFjaCBvdGhlci4uLlxuICAgKi9cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaW5wdXRcIj5cbiAgICAgIHsvKiBUaGlzIGlzIGEgY29tbWVudCB3aXRoaW4gdGhlIEpTWC4gTm90aWNlIHRoYXQgaXQncyBhIFR5cGVTY3JpcHQgY29tbWVudCB3cmFwcGVkIGluXG4gICAgICAgICAgICBicmFjZXMsIHNvIHRoYXQgUmVhY3Qga25vd3MgaXQgc2hvdWxkIGJlIGludGVycHJldGVkIGFzIFR5cGVTY3JpcHQgKi99XG4gICAgICB7LyogSSBvcHRlZCB0byB1c2UgdGhpcyBIVE1MIHRhZzsgeW91IGRvbid0IG5lZWQgdG8uIEl0IHN0cnVjdHVyZXMgbXVsdGlwbGUgaW5wdXQgZmllbGRzXG4gICAgICAgICAgICBpbnRvIGEgc2luZ2xlIHVuaXQsIHdoaWNoIG1ha2VzIGl0IGVhc2llciBmb3Igc2NyZWVucmVhZGVycyB0byBuYXZpZ2F0ZS4gKi99XG4gICAgICA8ZmllbGRzZXQ+XG4gICAgICAgIDxsZWdlbmQ+RW50ZXIgYSBjb21tYW5kOjwvbGVnZW5kPlxuICAgICAgICA8Q29udHJvbGxlZElucHV0XG4gICAgICAgICAgdmFsdWU9e2NvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgc2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgYXJpYUxhYmVsPXtcIkNvbW1hbmQgaW5wdXRcIn1cbiAgICAgICAgLz5cbiAgICAgIDwvZmllbGRzZXQ+XG4gICAgICB7LyogVE9ETzogQ3VycmVudGx5IHRoaXMgYnV0dG9uIGp1c3QgY291bnRzIHVwLCBjYW4gd2UgbWFrZSBpdCBwdXNoIHRoZSBjb250ZW50cyBvZiB0aGUgaW5wdXQgYm94IHRvIHRoZSBoaXN0b3J5PyovfVxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyl9PlN1Ym1pdDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvMjFrZW5uL0Rlc2t0b3AvY3MwMzIwL21vY2stdG5nYW1wcmEtd2NoeXVuL3NyYy9jb21wb25lbnRzL1JFUExJbnB1dC50c3gifQ==