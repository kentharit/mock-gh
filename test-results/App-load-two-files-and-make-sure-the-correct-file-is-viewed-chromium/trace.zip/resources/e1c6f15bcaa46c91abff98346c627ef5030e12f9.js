import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/OutputBox.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function OutputBox({
  command,
  data,
  mode
}) {
  if (mode === "brief") {
    if (Array.isArray(data)) {
      return /* @__PURE__ */ jsxDEV("div", { className: "bordered-div", children: /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tbody", { children: data.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 28,
        columnNumber: 49
      }, this)) }, rowIndex, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 27,
        columnNumber: 44
      }, this)) }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 26,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 25,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 24,
        columnNumber: 14
      }, this);
    } else {
      return /* @__PURE__ */ jsxDEV("div", { className: "bordered-div", children: /* @__PURE__ */ jsxDEV("p", { children: [
        " ",
        data,
        " "
      ] }, void 0, true, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 35,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 34,
        columnNumber: 14
      }, this);
    }
  } else {
    if (Array.isArray(data)) {
      return /* @__PURE__ */ jsxDEV("div", { className: "bordered-div", children: [
        /* @__PURE__ */ jsxDEV("p", { children: [
          " Command: ",
          command,
          " "
        ] }, void 0, true, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 41,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: " Output: " }, void 0, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 42,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tbody", { children: data.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 46,
          columnNumber: 49
        }, this)) }, rowIndex, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 45,
          columnNumber: 44
        }, this)) }, void 0, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 44,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 43,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 40,
        columnNumber: 14
      }, this);
    } else {
      return /* @__PURE__ */ jsxDEV("div", { className: "bordered-div", children: [
        /* @__PURE__ */ jsxDEV("p", { children: [
          " Command: ",
          command,
          " "
        ] }, void 0, true, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 53,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          " Output: ",
          data,
          " "
        ] }, void 0, true, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 54,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 52,
        columnNumber: 14
      }, this);
    }
  }
}
_c = OutputBox;
var _c;
$RefreshReg$(_c, "OutputBox");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJvQjtBQTFCcEIsT0FBTyxvQkFBb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFhcEIsZ0JBQVNBLFVBQVU7QUFBQSxFQUFFQztBQUFBQSxFQUFTQztBQUFBQSxFQUFNQztBQUFxQixHQUFHO0FBRWpFLE1BQUlBLFNBQVMsU0FBUztBQUNwQixRQUFJQyxNQUFNQyxRQUFRSCxJQUFJLEdBQUc7QUFHdkIsYUFDRSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2IsaUNBQUMsV0FDQyxpQ0FBQyxXQUNFQSxlQUFLSSxJQUFJLENBQUNDLEtBQUtDLGFBQ2QsdUJBQUMsUUFDRUQsY0FBSUQsSUFBSSxDQUFDRyxNQUFNQyxjQUNkLHVCQUFDLFFBQW9CRCxrQkFBWkMsV0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCLENBQzNCLEtBSE1GLFVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLENBQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxJQUVKLE9BQU87QUFDTCxhQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFDYixpQ0FBQyxPQUFFO0FBQUE7QUFBQSxRQUFFTjtBQUFBQSxRQUFLO0FBQUEsV0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVcsS0FEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUVKO0FBQUEsRUFDRixPQUFPO0FBQ0wsUUFBSUUsTUFBTUMsUUFBUUgsSUFBSSxHQUFHO0FBQ3ZCLGFBQ0UsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsT0FBRTtBQUFBO0FBQUEsVUFBV0Q7QUFBQUEsVUFBUTtBQUFBLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxRQUN2Qix1QkFBQyxPQUFFLHlCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQ1osdUJBQUMsV0FDQyxpQ0FBQyxXQUNFQyxlQUFLSSxJQUFJLENBQUNDLEtBQUtDLGFBQ2QsdUJBQUMsUUFDRUQsY0FBSUQsSUFBSSxDQUFDRyxNQUFNQyxjQUNkLHVCQUFDLFFBQW9CRCxrQkFBWkMsV0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCLENBQzNCLEtBSE1GLFVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLENBQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxXQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLElBRUosT0FBTztBQUNMLGFBQ0UsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsT0FBRTtBQUFBO0FBQUEsVUFBV1A7QUFBQUEsVUFBUTtBQUFBLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxRQUN2Qix1QkFBQyxPQUFFO0FBQUE7QUFBQSxVQUFVQztBQUFBQSxVQUFLO0FBQUEsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQjtBQUFBLFdBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLElBRUo7QUFBQSxFQUNGO0FBQ0Y7QUFBQ1MsS0F4RGVYO0FBQVMsSUFBQVc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk91dHB1dEJveCIsImNvbW1hbmQiLCJkYXRhIiwibW9kZSIsIkFycmF5IiwiaXNBcnJheSIsIm1hcCIsInJvdyIsInJvd0luZGV4IiwiY2VsbCIsImNlbGxJbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiT3V0cHV0Qm94LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiB9IGZyb20gXCJyZWFjdFwiO1xuXG4vLyBSZW1lbWJlciB0aGF0IHBhcmFtZXRlciBuYW1lcyBkb24ndCBuZWNlc3NhcmlseSBuZWVkIHRvIG92ZXJsYXA7XG4vLyBJIGNvdWxkIHVzZSBkaWZmZXJlbnQgdmFyaWFibGUgbmFtZXMgaW4gdGhlIGFjdHVhbCBmdW5jdGlvbi5cbmludGVyZmFjZSBPdXRwdXRCb3hQcm9wcyB7XG4gIGNvbW1hbmQ6IHN0cmluZztcbiAgZGF0YTogc3RyaW5nW11bXSB8IHN0cmluZztcbiAgbW9kZTogc3RyaW5nO1xufVxuXG4vLyBJbnB1dCBib3hlcyBjb250YWluIHN0YXRlLiBXZSB3YW50IHRvIG1ha2Ugc3VyZSBSZWFjdCBpcyBtYW5hZ2luZyB0aGF0IHN0YXRlLFxuLy8gICBzbyB3ZSBoYXZlIGEgc3BlY2lhbCBjb21wb25lbnQgdGhhdCB3cmFwcyB0aGUgaW5wdXQgYm94LlxuZXhwb3J0IGZ1bmN0aW9uIE91dHB1dEJveCh7IGNvbW1hbmQsIGRhdGEsIG1vZGUgfTogT3V0cHV0Qm94UHJvcHMpIHtcbiAgLy8gICByZXR1cm4gbW9kZSA9PT0gXCJicmllZlwiID8gPHA+IHtjb21tYW5kfSA8L3A+IDogPHA+IG5vIGNvbW1hbmQgPC9wPjtcbiAgaWYgKG1vZGUgPT09IFwiYnJpZWZcIikge1xuICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAvLyBDaGVjayBpZiBkYXRhIGlzIGEgbGlzdCBvZiBsaXN0IG9mIHN0cmluZ3MgKHN0cmluZ1tdW10pXG4gICAgICAvLyBJZiBzbywgZ2VuZXJhdGUgYW4gSFRNTCB0YWJsZVxuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXJlZC1kaXZcIj5cbiAgICAgICAgICA8dGFibGU+XG4gICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgIHtkYXRhLm1hcCgocm93LCByb3dJbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgIDx0ciBrZXk9e3Jvd0luZGV4fT5cbiAgICAgICAgICAgICAgICAgIHtyb3cubWFwKChjZWxsLCBjZWxsSW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHRkIGtleT17Y2VsbEluZGV4fT57Y2VsbH08L3RkPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXJlZC1kaXZcIj5cbiAgICAgICAgICA8cD4ge2RhdGF9IDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShkYXRhKSkge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXJlZC1kaXZcIj5cbiAgICAgICAgICA8cD4gQ29tbWFuZDoge2NvbW1hbmR9IDwvcD5cbiAgICAgICAgICA8cD4gT3V0cHV0OiA8L3A+XG4gICAgICAgICAgPHRhYmxlPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICB7ZGF0YS5tYXAoKHJvdywgcm93SW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtyb3dJbmRleH0+XG4gICAgICAgICAgICAgICAgICB7cm93Lm1hcCgoY2VsbCwgY2VsbEluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBrZXk9e2NlbGxJbmRleH0+e2NlbGx9PC90ZD5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyZWQtZGl2XCI+XG4gICAgICAgICAgPHA+IENvbW1hbmQ6IHtjb21tYW5kfSA8L3A+XG4gICAgICAgICAgPHA+IE91dHB1dDoge2RhdGF9IDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cbiAgfVxufVxuIl0sImZpbGUiOiIvVXNlcnMvMjFrZW5uL0Rlc2t0b3AvY3MwMzIwL21vY2stdG5nYW1wcmEtd2NoeXVuL3NyYy9jb21wb25lbnRzL091dHB1dEJveC50c3gifQ==