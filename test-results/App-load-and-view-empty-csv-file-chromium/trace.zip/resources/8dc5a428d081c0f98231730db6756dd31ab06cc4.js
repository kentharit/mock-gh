import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
import { OutputBox } from "/src/components/OutputBox.tsx";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.history.map((historyTuple, index) => /* @__PURE__ */ jsxDEV(OutputBox, { command: historyTuple[0], data: historyTuple[1], mode: historyTuple[2] }, void 0, false, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLHistory.tsx",
    lineNumber: 14,
    columnNumber: 51
  }, this)) }, void 0, false, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLHistory.tsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JRO0FBaEJSLE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNCLFNBQVNBLGlCQUFpQjtBQVFuQixnQkFBU0MsWUFBWUMsT0FBeUI7QUFDbkQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0JBSVpBLGdCQUFNQyxRQUFRQyxJQUFJLENBQUNDLGNBQWNDLFVBQ2hDLHVCQUFDLGFBQ0MsU0FBU0QsYUFBYSxDQUFDLEdBQ3ZCLE1BQU1BLGFBQWEsQ0FBQyxHQUNwQixNQUFNQSxhQUFhLENBQUMsS0FIdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUd3QixDQUV6QixLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUVKO0FBQUNFLEtBZmVOO0FBQVcsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk91dHB1dEJveCIsIlJFUExIaXN0b3J5IiwicHJvcHMiLCJoaXN0b3J5IiwibWFwIiwiaGlzdG9yeVR1cGxlIiwiaW5kZXgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExIaXN0b3J5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IE91dHB1dEJveCB9IGZyb20gXCIuL091dHB1dEJveFwiO1xuXG5pbnRlcmZhY2UgUkVQTEhpc3RvcnlQcm9wcyB7XG4gIC8vIFRPRE86IEZpbGwgd2l0aCBzb21lIHNoYXJlZCBzdGF0ZSB0cmFja2luZyBhbGwgdGhlIHB1c2hlZCBjb21tYW5kc1xuICAvLyBDSEFOR0VEXG4gIGhpc3Rvcnk6IFtzdHJpbmcsIHN0cmluZ1tdW10gfCBzdHJpbmcsIHN0cmluZ11bXTtcbiAgbW9kZTogc3RyaW5nO1xufVxuZXhwb3J0IGZ1bmN0aW9uIFJFUExIaXN0b3J5KHByb3BzOiBSRVBMSGlzdG9yeVByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIj5cbiAgICAgIHsvKiBUaGlzIGlzIHdoZXJlIGNvbW1hbmQgaGlzdG9yeSB3aWxsIGdvICovfVxuICAgICAgey8qIFRPRE86IFRvIGdvIHRocm91Z2ggYWxsIHRoZSBwdXNoZWQgY29tbWFuZHMuLi4gdHJ5IHRoZSAubWFwKCkgZnVuY3Rpb24hICovfVxuICAgICAgey8qIENIQU5HRUQgKi99XG4gICAgICB7cHJvcHMuaGlzdG9yeS5tYXAoKGhpc3RvcnlUdXBsZSwgaW5kZXgpID0+IChcbiAgICAgICAgPE91dHB1dEJveFxuICAgICAgICAgIGNvbW1hbmQ9e2hpc3RvcnlUdXBsZVswXX1cbiAgICAgICAgICBkYXRhPXtoaXN0b3J5VHVwbGVbMV19XG4gICAgICAgICAgbW9kZT17aGlzdG9yeVR1cGxlWzJdfVxuICAgICAgICAvPlxuICAgICAgKSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy8yMWtlbm4vRGVza3RvcC9jczAzMjAvbW9jay10bmdhbXByYS13Y2h5dW4vc3JjL2NvbXBvbmVudHMvUkVQTEhpc3RvcnkudHN4In0=