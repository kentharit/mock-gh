import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f35b47c0"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import all_data from "/src/mocked-data/mockedJson.ts";
var data = all_data["data"];
var searchData = all_data["search_data"];
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [loadedFilepath, setloadedFilepath] = useState("");
  const [hasLoaded, setHasLoaded] = useState(false);
  function handleSubmit(commandString2) {
    var splitted = commandString2.split(" ");
    var command = splitted[0];
    var output;
    if (command == "mode") {
      if (splitted.length == 1) {
        props.mode === "brief" ? props.setMode("verbose") : props.setMode("brief");
        output = "Successfully changed mode";
      } else {
        output = "Wrong number of arguments for mode command";
      }
    } else if (command == "load_file") {
      if (splitted.length == 2) {
        var filepath = splitted[1];
        if (filepath in data) {
          output = "File successfully loaded";
          console.log(filepath);
          setloadedFilepath(filepath);
          setHasLoaded(true);
        } else {
          output = "File not found in directory";
        }
      } else {
        output = "Wrong number of arguments for load command";
      }
    } else if (command == "view") {
      if (hasLoaded) {
        if (splitted.length == 1) {
          output = loadedFilepath in data ? data[loadedFilepath] : "File not found in directory";
        } else {
          output = "Wrong number of arguments for view command";
        }
      } else {
        output = "Cannot call view before load";
      }
    } else if (command == "search") {
      if (hasLoaded) {
        if (splitted.length == 3) {
          var column = splitted[1];
          var value = splitted[2];
          var key = [column, value];
          if (loadedFilepath in searchData) {
            var filepath_commands = searchData[loadedFilepath];
            output = JSON.stringify(key) in filepath_commands ? filepath_commands[JSON.stringify(key)] : "Command does not exist in mocked search data";
          } else {
            output = "File not found in directory";
          }
        } else {
          output = "Wrong number of arguments for search command";
        }
      } else {
        output = "Cannot call search before load";
      }
    } else {
      output = "Not a valid command";
    }
    if (typeof output == "undefined") {
      output = "Not a valid command";
    }
    props.setHistory([...props.history, [commandString2, output, props.mode]]);
    setCount(count + 1);
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
        lineNumber: 106,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
      lineNumber: 104,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: "Submit" }, void 0, false, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
    lineNumber: 99,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "Wd0Zuds1vl8hqfXy0qgHPp/1zxM=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUhROzs7Ozs7Ozs7Ozs7Ozs7OztBQXpIUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsT0FBT0MsY0FBYztBQUVyQixJQUFJQyxPQUFPRCxTQUFTLE1BQU07QUFDMUIsSUFBSUUsYUFBYUYsU0FBUyxhQUFhO0FBYWhDLGdCQUFTRyxVQUFVQyxPQUF1QjtBQUFBQyxLQUFBO0FBRy9DLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUlULFNBQWlCLEVBQUU7QUFFN0QsUUFBTSxDQUFDVSxPQUFPQyxRQUFRLElBQUlYLFNBQWlCLENBQUM7QUFFNUMsUUFBTSxDQUFDWSxnQkFBZ0JDLGlCQUFpQixJQUFJYixTQUFpQixFQUFFO0FBRS9ELFFBQU0sQ0FBQ2MsV0FBV0MsWUFBWSxJQUFJZixTQUFrQixLQUFLO0FBR3pELFdBQVNnQixhQUFhUixnQkFBdUI7QUFDM0MsUUFBSVMsV0FBV1QsZUFBY1UsTUFBTSxHQUFHO0FBQ3RDLFFBQUlDLFVBQVVGLFNBQVMsQ0FBQztBQUN4QixRQUFJRztBQUVKLFFBQUlELFdBQVcsUUFBUTtBQUNyQixVQUFJRixTQUFTSSxVQUFVLEdBQUc7QUFDeEJmLGNBQU1nQixTQUFTLFVBQ1hoQixNQUFNaUIsUUFBUSxTQUFTLElBQ3ZCakIsTUFBTWlCLFFBQVEsT0FBTztBQUN6QkgsaUJBQVM7QUFBQSxNQUNYLE9BQU87QUFDTEEsaUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRixXQUFXRCxXQUFXLGFBQWE7QUFFakMsVUFBSUYsU0FBU0ksVUFBVSxHQUFHO0FBQ3hCLFlBQUlHLFdBQVdQLFNBQVMsQ0FBQztBQUN6QixZQUFJTyxZQUFZckIsTUFBTTtBQUNwQmlCLG1CQUFTO0FBQ1RLLGtCQUFRQyxJQUFJRixRQUFRO0FBQ3BCWCw0QkFBa0JXLFFBQVE7QUFDMUJULHVCQUFhLElBQUk7QUFBQSxRQUNuQixPQUFPO0FBQ0xLLG1CQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0YsT0FBTztBQUNMQSxpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGLFdBQVdELFdBQVcsUUFBUTtBQUM1QixVQUFJTCxXQUFXO0FBQ2IsWUFBSUcsU0FBU0ksVUFBVSxHQUFHO0FBQ3hCRCxtQkFDRVIsa0JBQWtCVCxPQUNkQSxLQUFLUyxjQUFjLElBQ25CO0FBQUEsUUFDUixPQUFPO0FBQ0xRLG1CQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0YsT0FBTztBQUNMQSxpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGLFdBQVdELFdBQVcsVUFBVTtBQUM5QixVQUFJTCxXQUFXO0FBQ2IsWUFBSUcsU0FBU0ksVUFBVSxHQUFHO0FBRXhCLGNBQUlNLFNBQVNWLFNBQVMsQ0FBQztBQUN2QixjQUFJVyxRQUFRWCxTQUFTLENBQUM7QUFDdEIsY0FBSVksTUFBTSxDQUFDRixRQUFRQyxLQUFLO0FBRXhCLGNBQUloQixrQkFBa0JSLFlBQVk7QUFDaEMsZ0JBQUkwQixvQkFBb0IxQixXQUFXUSxjQUFjO0FBQ2pEUSxxQkFDRVcsS0FBS0MsVUFBVUgsR0FBRyxLQUFLQyxvQkFDbkJBLGtCQUFrQkMsS0FBS0MsVUFBVUgsR0FBRyxDQUFDLElBQ3JDO0FBQUEsVUFDUixPQUFPO0FBQ0xULHFCQUFTO0FBQUEsVUFDWDtBQUFBLFFBQ0YsT0FBTztBQUNMQSxtQkFBUztBQUFBLFFBQ1g7QUFBQSxNQUNGLE9BQU87QUFDTEEsaUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRixPQUFPO0FBQ0xBLGVBQVM7QUFBQSxJQUNYO0FBRUEsUUFBSSxPQUFPQSxVQUFVLGFBQWE7QUFDaENBLGVBQVM7QUFBQSxJQUNYO0FBRUFkLFVBQU0yQixXQUFXLENBQUMsR0FBRzNCLE1BQU00QixTQUFTLENBQUMxQixnQkFBZVksUUFBUWQsTUFBTWdCLElBQUksQ0FBQyxDQUFDO0FBRXhFWCxhQUFTRCxRQUFRLENBQUM7QUFFbEJELHFCQUFpQixFQUFFO0FBQUEsRUFDckI7QUFLQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUtiO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLFlBQU8sZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLG1CQUNDLE9BQU9ELGVBQ1AsVUFBVUMsa0JBQ1YsV0FBVyxtQkFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzZCO0FBQUEsU0FML0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQSx1QkFBQyxZQUFPLFNBQVMsTUFBTU8sYUFBYVIsYUFBYSxHQUFHLHNCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsT0FkNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBO0FBRUo7QUFBQ0QsR0FqSGVGLFdBQVM7QUFBQThCLEtBQVQ5QjtBQUFTLElBQUE4QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJDb250cm9sbGVkSW5wdXQiLCJhbGxfZGF0YSIsImRhdGEiLCJzZWFyY2hEYXRhIiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsImxvYWRlZEZpbGVwYXRoIiwic2V0bG9hZGVkRmlsZXBhdGgiLCJoYXNMb2FkZWQiLCJzZXRIYXNMb2FkZWQiLCJoYW5kbGVTdWJtaXQiLCJzcGxpdHRlZCIsInNwbGl0IiwiY29tbWFuZCIsIm91dHB1dCIsImxlbmd0aCIsIm1vZGUiLCJzZXRNb2RlIiwiZmlsZXBhdGgiLCJjb25zb2xlIiwibG9nIiwiY29sdW1uIiwidmFsdWUiLCJrZXkiLCJmaWxlcGF0aF9jb21tYW5kcyIsIkpTT04iLCJzdHJpbmdpZnkiLCJzZXRIaXN0b3J5IiwiaGlzdG9yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENvbnRyb2xsZWRJbnB1dCB9IGZyb20gXCIuL0NvbnRyb2xsZWRJbnB1dFwiO1xuaW1wb3J0IGFsbF9kYXRhIGZyb20gXCIuLi9tb2NrZWQtZGF0YS9tb2NrZWRKc29uXCI7XG5cbnZhciBkYXRhID0gYWxsX2RhdGFbXCJkYXRhXCJdO1xudmFyIHNlYXJjaERhdGEgPSBhbGxfZGF0YVtcInNlYXJjaF9kYXRhXCJdO1xuXG5pbnRlcmZhY2UgUkVQTElucHV0UHJvcHMge1xuICAvLyBUT0RPOiBGaWxsIHRoaXMgd2l0aCBkZXNpcmVkIHByb3BzLi4uIE1heWJlIHNvbWV0aGluZyB0byBrZWVwIHRyYWNrIG9mIHRoZSBzdWJtaXR0ZWQgY29tbWFuZHNcbiAgLy8gQ0hBTkdFRFxuICBoaXN0b3J5OiBbc3RyaW5nLCBzdHJpbmdbXVtdIHwgc3RyaW5nLCBzdHJpbmddW107XG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPFtzdHJpbmcsIHN0cmluZyB8IHN0cmluZ1tdW10sIHN0cmluZ11bXT4+O1xuICBtb2RlOiBzdHJpbmc7XG4gIHNldE1vZGU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xufVxuXG4vLyBZb3UgY2FuIHVzZSBhIGN1c3RvbSBpbnRlcmZhY2Ugb3IgZXhwbGljaXQgZmllbGRzIG9yIGJvdGghIEFuIGFsdGVybmF0aXZlIHRvIHRoZSBjdXJyZW50IGZ1bmN0aW9uIGhlYWRlciBtaWdodCBiZTpcbi8vIFJFUExJbnB1dChoaXN0b3J5OiBzdHJpbmdbXSwgc2V0SGlzdG9yeTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nW10+PilcbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHM6IFJFUExJbnB1dFByb3BzKSB7XG4gIC8vIFJlbWVtYmVyOiBsZXQgUmVhY3QgbWFuYWdlIHN0YXRlIGluIHlvdXIgd2ViYXBwLlxuICAvLyBNYW5hZ2VzIHRoZSBjb250ZW50cyBvZiB0aGUgaW5wdXQgYm94XG4gIGNvbnN0IFtjb21tYW5kU3RyaW5nLCBzZXRDb21tYW5kU3RyaW5nXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIC8vIE1hbmFnZXMgdGhlIGN1cnJlbnQgYW1vdW50IG9mIHRpbWVzIHRoZSBidXR0b24gaXMgY2xpY2tlZFxuICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG5cbiAgY29uc3QgW2xvYWRlZEZpbGVwYXRoLCBzZXRsb2FkZWRGaWxlcGF0aF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuXG4gIGNvbnN0IFtoYXNMb2FkZWQsIHNldEhhc0xvYWRlZF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cbiAgLy8gVGhpcyBmdW5jdGlvbiBpcyB0cmlnZ2VyZWQgd2hlbiB0aGUgYnV0dG9uIGlzIGNsaWNrZWQuXG4gIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nOiBzdHJpbmcpIHtcbiAgICB2YXIgc3BsaXR0ZWQgPSBjb21tYW5kU3RyaW5nLnNwbGl0KFwiIFwiKTtcbiAgICB2YXIgY29tbWFuZCA9IHNwbGl0dGVkWzBdO1xuICAgIHZhciBvdXRwdXQ7XG5cbiAgICBpZiAoY29tbWFuZCA9PSBcIm1vZGVcIikge1xuICAgICAgaWYgKHNwbGl0dGVkLmxlbmd0aCA9PSAxKSB7XG4gICAgICAgIHByb3BzLm1vZGUgPT09IFwiYnJpZWZcIlxuICAgICAgICAgID8gcHJvcHMuc2V0TW9kZShcInZlcmJvc2VcIilcbiAgICAgICAgICA6IHByb3BzLnNldE1vZGUoXCJicmllZlwiKTtcbiAgICAgICAgb3V0cHV0ID0gXCJTdWNjZXNzZnVsbHkgY2hhbmdlZCBtb2RlXCI7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvdXRwdXQgPSBcIldyb25nIG51bWJlciBvZiBhcmd1bWVudHMgZm9yIG1vZGUgY29tbWFuZFwiO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PSBcImxvYWRfZmlsZVwiKSB7XG4gICAgICAvL1RPRE8gSEFORExFIEhFQURFUlxuICAgICAgaWYgKHNwbGl0dGVkLmxlbmd0aCA9PSAyKSB7XG4gICAgICAgIHZhciBmaWxlcGF0aCA9IHNwbGl0dGVkWzFdO1xuICAgICAgICBpZiAoZmlsZXBhdGggaW4gZGF0YSkge1xuICAgICAgICAgIG91dHB1dCA9IFwiRmlsZSBzdWNjZXNzZnVsbHkgbG9hZGVkXCI7XG4gICAgICAgICAgY29uc29sZS5sb2coZmlsZXBhdGgpO1xuICAgICAgICAgIHNldGxvYWRlZEZpbGVwYXRoKGZpbGVwYXRoKTtcbiAgICAgICAgICBzZXRIYXNMb2FkZWQodHJ1ZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb3V0cHV0ID0gXCJGaWxlIG5vdCBmb3VuZCBpbiBkaXJlY3RvcnlcIjtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb3V0cHV0ID0gXCJXcm9uZyBudW1iZXIgb2YgYXJndW1lbnRzIGZvciBsb2FkIGNvbW1hbmRcIjtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNvbW1hbmQgPT0gXCJ2aWV3XCIpIHtcbiAgICAgIGlmIChoYXNMb2FkZWQpIHtcbiAgICAgICAgaWYgKHNwbGl0dGVkLmxlbmd0aCA9PSAxKSB7XG4gICAgICAgICAgb3V0cHV0ID1cbiAgICAgICAgICAgIGxvYWRlZEZpbGVwYXRoIGluIGRhdGFcbiAgICAgICAgICAgICAgPyBkYXRhW2xvYWRlZEZpbGVwYXRoXVxuICAgICAgICAgICAgICA6IFwiRmlsZSBub3QgZm91bmQgaW4gZGlyZWN0b3J5XCI7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb3V0cHV0ID0gXCJXcm9uZyBudW1iZXIgb2YgYXJndW1lbnRzIGZvciB2aWV3IGNvbW1hbmRcIjtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb3V0cHV0ID0gXCJDYW5ub3QgY2FsbCB2aWV3IGJlZm9yZSBsb2FkXCI7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChjb21tYW5kID09IFwic2VhcmNoXCIpIHtcbiAgICAgIGlmIChoYXNMb2FkZWQpIHtcbiAgICAgICAgaWYgKHNwbGl0dGVkLmxlbmd0aCA9PSAzKSB7XG4gICAgICAgICAgLy8gSE9XIFRPIERFQUwgV0lUSCBTUEFDRVMgSU4gSU5QVVRcbiAgICAgICAgICB2YXIgY29sdW1uID0gc3BsaXR0ZWRbMV07XG4gICAgICAgICAgdmFyIHZhbHVlID0gc3BsaXR0ZWRbMl07XG4gICAgICAgICAgdmFyIGtleSA9IFtjb2x1bW4sIHZhbHVlXTtcblxuICAgICAgICAgIGlmIChsb2FkZWRGaWxlcGF0aCBpbiBzZWFyY2hEYXRhKSB7XG4gICAgICAgICAgICB2YXIgZmlsZXBhdGhfY29tbWFuZHMgPSBzZWFyY2hEYXRhW2xvYWRlZEZpbGVwYXRoXTtcbiAgICAgICAgICAgIG91dHB1dCA9XG4gICAgICAgICAgICAgIEpTT04uc3RyaW5naWZ5KGtleSkgaW4gZmlsZXBhdGhfY29tbWFuZHNcbiAgICAgICAgICAgICAgICA/IGZpbGVwYXRoX2NvbW1hbmRzW0pTT04uc3RyaW5naWZ5KGtleSldXG4gICAgICAgICAgICAgICAgOiBcIkNvbW1hbmQgZG9lcyBub3QgZXhpc3QgaW4gbW9ja2VkIHNlYXJjaCBkYXRhXCI7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG91dHB1dCA9IFwiRmlsZSBub3QgZm91bmQgaW4gZGlyZWN0b3J5XCI7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG91dHB1dCA9IFwiV3JvbmcgbnVtYmVyIG9mIGFyZ3VtZW50cyBmb3Igc2VhcmNoIGNvbW1hbmRcIjtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb3V0cHV0ID0gXCJDYW5ub3QgY2FsbCBzZWFyY2ggYmVmb3JlIGxvYWRcIjtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgb3V0cHV0ID0gXCJOb3QgYSB2YWxpZCBjb21tYW5kXCI7XG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBvdXRwdXQgPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgb3V0cHV0ID0gXCJOb3QgYSB2YWxpZCBjb21tYW5kXCI7XG4gICAgfVxuXG4gICAgcHJvcHMuc2V0SGlzdG9yeShbLi4ucHJvcHMuaGlzdG9yeSwgW2NvbW1hbmRTdHJpbmcsIG91dHB1dCwgcHJvcHMubW9kZV1dKTtcblxuICAgIHNldENvdW50KGNvdW50ICsgMSk7XG5cbiAgICBzZXRDb21tYW5kU3RyaW5nKFwiXCIpO1xuICB9XG4gIC8qKlxuICAgKiBXZSBzdWdnZXN0IGJyZWFraW5nIGRvd24gdGhpcyBjb21wb25lbnQgaW50byBzbWFsbGVyIGNvbXBvbmVudHMsIHRoaW5rIGFib3V0IHRoZSBpbmRpdmlkdWFsIHBpZWNlc1xuICAgKiBvZiB0aGUgUkVQTCBhbmQgaG93IHRoZXkgY29ubmVjdCB0byBlYWNoIG90aGVyLi4uXG4gICAqL1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbC1pbnB1dFwiPlxuICAgICAgey8qIFRoaXMgaXMgYSBjb21tZW50IHdpdGhpbiB0aGUgSlNYLiBOb3RpY2UgdGhhdCBpdCdzIGEgVHlwZVNjcmlwdCBjb21tZW50IHdyYXBwZWQgaW5cbiAgICAgICAgICAgIGJyYWNlcywgc28gdGhhdCBSZWFjdCBrbm93cyBpdCBzaG91bGQgYmUgaW50ZXJwcmV0ZWQgYXMgVHlwZVNjcmlwdCAqL31cbiAgICAgIHsvKiBJIG9wdGVkIHRvIHVzZSB0aGlzIEhUTUwgdGFnOyB5b3UgZG9uJ3QgbmVlZCB0by4gSXQgc3RydWN0dXJlcyBtdWx0aXBsZSBpbnB1dCBmaWVsZHNcbiAgICAgICAgICAgIGludG8gYSBzaW5nbGUgdW5pdCwgd2hpY2ggbWFrZXMgaXQgZWFzaWVyIGZvciBzY3JlZW5yZWFkZXJzIHRvIG5hdmlnYXRlLiAqL31cbiAgICAgIDxmaWVsZHNldD5cbiAgICAgICAgPGxlZ2VuZD5FbnRlciBhIGNvbW1hbmQ6PC9sZWdlbmQ+XG4gICAgICAgIDxDb250cm9sbGVkSW5wdXRcbiAgICAgICAgICB2YWx1ZT17Y29tbWFuZFN0cmluZ31cbiAgICAgICAgICBzZXRWYWx1ZT17c2V0Q29tbWFuZFN0cmluZ31cbiAgICAgICAgICBhcmlhTGFiZWw9e1wiQ29tbWFuZCBpbnB1dFwifVxuICAgICAgICAvPlxuICAgICAgPC9maWVsZHNldD5cbiAgICAgIHsvKiBUT0RPOiBDdXJyZW50bHkgdGhpcyBidXR0b24ganVzdCBjb3VudHMgdXAsIGNhbiB3ZSBtYWtlIGl0IHB1c2ggdGhlIGNvbnRlbnRzIG9mIHRoZSBpbnB1dCBib3ggdG8gdGhlIGhpc3Rvcnk/Ki99XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKX0+U3VibWl0PC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy8yMWtlbm4vRGVza3RvcC9jczAzMjAvbW9jay10bmdhbXByYS13Y2h5dW4vc3JjL2NvbXBvbmVudHMvUkVQTElucHV0LnRzeCJ9