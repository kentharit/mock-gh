import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=f35b47c0"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import all_data from "/src/mocked-data/mockedJson.ts";
var data = all_data["data"];
var searchData = all_data["search_data"];
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [loadedFilepath, setloadedFilepath] = useState("");
  const [hasLoaded, setHasLoaded] = useState(false);
  function handleSubmit(commandString2) {
    var splitted = commandString2.split(" ");
    var command = splitted[0];
    var output;
    if (command == "mode") {
      if (splitted.length == 1) {
        props.mode === "brief" ? props.setMode("verbose") : props.setMode("brief");
        output = "Successfully changed mode";
      } else {
        output = "Wrong number of arguments for mode command";
      }
    } else if (command == "load_file") {
      if (splitted.length == 2) {
        var filepath = splitted[1];
        if (filepath in data) {
          output = "File successfully loaded";
          console.log(filepath);
          setloadedFilepath(filepath);
          setHasLoaded(true);
        } else {
          output = "File not found in directory";
        }
      } else {
        output = "Wrong number of arguments for load command";
      }
    } else if (command == "view") {
      if (hasLoaded) {
        if (splitted.length == 1) {
          output = loadedFilepath in data ? data[loadedFilepath] : "File not found in directory";
        } else {
          output = "Wrong number of arguments for view command";
        }
      } else {
        output = "Cannot call view before load";
      }
    } else if (command == "search") {
      if (hasLoaded) {
        if (splitted.length == 3) {
          var column = splitted[1];
          var value = splitted[2];
          var key = [column, value];
          if (loadedFilepath in searchData) {
            var filepath_commands = searchData[loadedFilepath];
            output = JSON.stringify(key) in filepath_commands ? filepath_commands[JSON.stringify(key)] : "Command does not exist in mocked search data";
          } else {
            output = "File not found in directory";
          }
        } else {
          output = "Wrong number of arguments for search command";
        }
      } else {
        output = "Cannot call search before load";
      }
    } else {
      output = "Not a valid command";
    }
    if (typeof output == "undefined") {
      output = "Not a valid command";
    }
    props.setHistory([...props.history, [commandString2, output, props.mode]]);
    setCount(count + 1);
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
        lineNumber: 111,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: "Submit" }, void 0, false, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
      lineNumber: 114,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx",
    lineNumber: 104,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "Wd0Zuds1vl8hqfXy0qgHPp/1zxM=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0hROzs7Ozs7Ozs7Ozs7Ozs7OztBQS9IUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsT0FBT0MsY0FBYztBQUVyQixJQUFJQyxPQUFPRCxTQUFTLE1BQU07QUFDMUIsSUFBSUUsYUFBYUYsU0FBUyxhQUFhO0FBdUJoQyxnQkFBU0csVUFBVUMsT0FBdUI7QUFBQUMsS0FBQTtBQUMvQyxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJVCxTQUFpQixFQUFFO0FBQzdELFFBQU0sQ0FBQ1UsT0FBT0MsUUFBUSxJQUFJWCxTQUFpQixDQUFDO0FBRTVDLFFBQU0sQ0FBQ1ksZ0JBQWdCQyxpQkFBaUIsSUFBSWIsU0FBaUIsRUFBRTtBQUUvRCxRQUFNLENBQUNjLFdBQVdDLFlBQVksSUFBSWYsU0FBa0IsS0FBSztBQUV6RCxXQUFTZ0IsYUFBYVIsZ0JBQXVCO0FBQzNDLFFBQUlTLFdBQVdULGVBQWNVLE1BQU0sR0FBRztBQUN0QyxRQUFJQyxVQUFVRixTQUFTLENBQUM7QUFDeEIsUUFBSUc7QUFFSixRQUFJRCxXQUFXLFFBQVE7QUFDckIsVUFBSUYsU0FBU0ksVUFBVSxHQUFHO0FBQ3hCZixjQUFNZ0IsU0FBUyxVQUNYaEIsTUFBTWlCLFFBQVEsU0FBUyxJQUN2QmpCLE1BQU1pQixRQUFRLE9BQU87QUFDekJILGlCQUFTO0FBQUEsTUFDWCxPQUFPO0FBQ0xBLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0YsV0FBV0QsV0FBVyxhQUFhO0FBRWpDLFVBQUlGLFNBQVNJLFVBQVUsR0FBRztBQUN4QixZQUFJRyxXQUFXUCxTQUFTLENBQUM7QUFDekIsWUFBSU8sWUFBWXJCLE1BQU07QUFDcEJpQixtQkFBUztBQUNUSyxrQkFBUUMsSUFBSUYsUUFBUTtBQUNwQlgsNEJBQWtCVyxRQUFRO0FBQzFCVCx1QkFBYSxJQUFJO0FBQUEsUUFDbkIsT0FBTztBQUNMSyxtQkFBUztBQUFBLFFBQ1g7QUFBQSxNQUNGLE9BQU87QUFDTEEsaUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRixXQUFXRCxXQUFXLFFBQVE7QUFDNUIsVUFBSUwsV0FBVztBQUNiLFlBQUlHLFNBQVNJLFVBQVUsR0FBRztBQUN4QkQsbUJBQ0VSLGtCQUFrQlQsT0FDZEEsS0FBS1MsY0FBYyxJQUNuQjtBQUFBLFFBQ1IsT0FBTztBQUNMUSxtQkFBUztBQUFBLFFBQ1g7QUFBQSxNQUNGLE9BQU87QUFDTEEsaUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRixXQUFXRCxXQUFXLFVBQVU7QUFDOUIsVUFBSUwsV0FBVztBQUNiLFlBQUlHLFNBQVNJLFVBQVUsR0FBRztBQUV4QixjQUFJTSxTQUFTVixTQUFTLENBQUM7QUFDdkIsY0FBSVcsUUFBUVgsU0FBUyxDQUFDO0FBQ3RCLGNBQUlZLE1BQU0sQ0FBQ0YsUUFBUUMsS0FBSztBQUV4QixjQUFJaEIsa0JBQWtCUixZQUFZO0FBQ2hDLGdCQUFJMEIsb0JBQW9CMUIsV0FBV1EsY0FBYztBQUNqRFEscUJBQ0VXLEtBQUtDLFVBQVVILEdBQUcsS0FBS0Msb0JBQ25CQSxrQkFBa0JDLEtBQUtDLFVBQVVILEdBQUcsQ0FBQyxJQUNyQztBQUFBLFVBQ1IsT0FBTztBQUNMVCxxQkFBUztBQUFBLFVBQ1g7QUFBQSxRQUNGLE9BQU87QUFDTEEsbUJBQVM7QUFBQSxRQUNYO0FBQUEsTUFDRixPQUFPO0FBQ0xBLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0YsT0FBTztBQUNMQSxlQUFTO0FBQUEsSUFDWDtBQUVBLFFBQUksT0FBT0EsVUFBVSxhQUFhO0FBQ2hDQSxlQUFTO0FBQUEsSUFDWDtBQUVBZCxVQUFNMkIsV0FBVyxDQUFDLEdBQUczQixNQUFNNEIsU0FBUyxDQUFDMUIsZ0JBQWVZLFFBQVFkLE1BQU1nQixJQUFJLENBQUMsQ0FBQztBQUV4RVgsYUFBU0QsUUFBUSxDQUFDO0FBRWxCRCxxQkFBaUIsRUFBRTtBQUFBLEVBQ3JCO0FBS0EsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FLYjtBQUFBLDJCQUFDLGNBQ0M7QUFBQSw2QkFBQyxZQUFPLGdDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxtQkFDQyxPQUFPRCxlQUNQLFVBQVVDLGtCQUNWLFdBQVcsbUJBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUc2QjtBQUFBLFNBTC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUEsdUJBQUMsWUFBTyxTQUFTLE1BQU1PLGFBQWFSLGFBQWEsR0FBRyxzQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRDtBQUFBLE9BZDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQTtBQUVKO0FBQUNELEdBN0dlRixXQUFTO0FBQUE4QixLQUFUOUI7QUFBUyxJQUFBOEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwiYWxsX2RhdGEiLCJkYXRhIiwic2VhcmNoRGF0YSIsIlJFUExJbnB1dCIsInByb3BzIiwiX3MiLCJjb21tYW5kU3RyaW5nIiwic2V0Q29tbWFuZFN0cmluZyIsImNvdW50Iiwic2V0Q291bnQiLCJsb2FkZWRGaWxlcGF0aCIsInNldGxvYWRlZEZpbGVwYXRoIiwiaGFzTG9hZGVkIiwic2V0SGFzTG9hZGVkIiwiaGFuZGxlU3VibWl0Iiwic3BsaXR0ZWQiLCJzcGxpdCIsImNvbW1hbmQiLCJvdXRwdXQiLCJsZW5ndGgiLCJtb2RlIiwic2V0TW9kZSIsImZpbGVwYXRoIiwiY29uc29sZSIsImxvZyIsImNvbHVtbiIsInZhbHVlIiwia2V5IiwiZmlsZXBhdGhfY29tbWFuZHMiLCJKU09OIiwic3RyaW5naWZ5Iiwic2V0SGlzdG9yeSIsImhpc3RvcnkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9Db250cm9sbGVkSW5wdXRcIjtcbmltcG9ydCBhbGxfZGF0YSBmcm9tIFwiLi4vbW9ja2VkLWRhdGEvbW9ja2VkSnNvblwiO1xuXG52YXIgZGF0YSA9IGFsbF9kYXRhW1wiZGF0YVwiXTtcbnZhciBzZWFyY2hEYXRhID0gYWxsX2RhdGFbXCJzZWFyY2hfZGF0YVwiXTtcblxuaW50ZXJmYWNlIFJFUExJbnB1dFByb3BzIHtcbiAgaGlzdG9yeTogW3N0cmluZywgc3RyaW5nW11bXSB8IHN0cmluZywgc3RyaW5nXVtdO1xuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxbc3RyaW5nLCBzdHJpbmcgfCBzdHJpbmdbXVtdLCBzdHJpbmddW10+PjtcbiAgbW9kZTogc3RyaW5nO1xuICBzZXRNb2RlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+Pjtcbn1cblxuLyoqXG4gKiBSRVBMIGlucHV0IGNsYXNz4oCZcyBtYWluIHJvbGUgaXMgdG8gbWFuYWdlIGFsbCB0aGUgaW5wdXRzIHRoYXQgYXJlIHBhc3NlZCB0aHJvdWdoIHRoZSB0ZXh0IGJveC5cbiAqIFdlIHdpbGwgaW5pdGlhbGx5IGNvdW50IGhvdyBtYW55IHRpbWVzIHRoZSBzdWJtaXQgYnV0dG9uIGlzIHByZXNzZWQuXG4gKiBUaGVuIHdlIHdpbGwgYWxsb3cgdGhlIHVzZXIgdG8gaW5wdXQgbW9kZSBpbiB0aGUgdGV4dGJveC5cbiAqIFdoZW4gbW9kZSBpcyBpbml0aWFsbHkgY2FsbGVkLCBpdCB3aWxsIGJlIGluIGEgYnJpZWYgbW9kZSwgYW5kIGlmIHRoZSB1c2VyIHR5cGVzIGluIG1vZGUgYWdhaW4sXG4gKiBcdGl0IHdpbGwgZ28gdG8gdmVyYm9zZSBzdGF0ZS5cbiAqIFRoZXJlIGFyZSBhbHNvIG90aGVyIGZ1bmN0aW9uYWxpdGllcyBsaWtlIHZpZXcgY29tbWFuZCwgYW5kIHRoZSBzdWNjZXNzXG4gKiBcdG1lc3NhZ2Ugd2lsbCBiZSByZXR1cm5lZCB3aGVuIHRoZSBmaWxlIGlzIGluIHRoZSBjb3JyZWN0IENTViBmb3JtYXQuXG4gKiBGaW5hbGx5LCB0aGUgbGFzdCBjb21tYW5kIHdlIGhhdmUgaXMgc2VhcmNoIHdoZXJlIHdlIHdpbGwgdXNlIOKAnEpTT04uc3RyaW5nZnnigJ0gbWV0aG9kIHRvIGZpbmRcbiAqIFx0dGhlIHZhbHVlIHRoZSB1c2VyIGhvcGVzIHRvIHNlYXJjaCBhbmQgd2lsbCBsb29rIGZvciBpdCBpbnNpZGUgdGhlIGxvYWRlZCBDU1YgZmlsZS5cbiAqIEFsbCB0aGUgZXJyb3JzIGFyZSBjYXVnaHQgYXMgd2Ugd2lsbCBiZSBsb29raW5nIGZvciBjYXNlcyB0aGF0IGhhdmUgbm8gZmlsZSBmb3VuZCxcbiAqIFx0aW5wdXR0aW5nIHdyb25nIHZhbHVlIGZvciBzZWFyY2ggcmVzdWx0cywgY2FsbGluZyBzZWFyY2ggYmVmb3JlIGxvYWRpbmcsIG9yIHBhc3NpbmdcbiAqIFx0dGhyb3VnaCByYW5kb20gbWVzc2FnZSBpbnNpZGUgdGhlIHRvb2wgYmFyLlxuICovXG5leHBvcnQgZnVuY3Rpb24gUkVQTElucHV0KHByb3BzOiBSRVBMSW5wdXRQcm9wcykge1xuICBjb25zdCBbY29tbWFuZFN0cmluZywgc2V0Q29tbWFuZFN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG5cbiAgY29uc3QgW2xvYWRlZEZpbGVwYXRoLCBzZXRsb2FkZWRGaWxlcGF0aF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuXG4gIGNvbnN0IFtoYXNMb2FkZWQsIHNldEhhc0xvYWRlZF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmc6IHN0cmluZykge1xuICAgIHZhciBzcGxpdHRlZCA9IGNvbW1hbmRTdHJpbmcuc3BsaXQoXCIgXCIpO1xuICAgIHZhciBjb21tYW5kID0gc3BsaXR0ZWRbMF07XG4gICAgdmFyIG91dHB1dDtcblxuICAgIGlmIChjb21tYW5kID09IFwibW9kZVwiKSB7XG4gICAgICBpZiAoc3BsaXR0ZWQubGVuZ3RoID09IDEpIHtcbiAgICAgICAgcHJvcHMubW9kZSA9PT0gXCJicmllZlwiXG4gICAgICAgICAgPyBwcm9wcy5zZXRNb2RlKFwidmVyYm9zZVwiKVxuICAgICAgICAgIDogcHJvcHMuc2V0TW9kZShcImJyaWVmXCIpO1xuICAgICAgICBvdXRwdXQgPSBcIlN1Y2Nlc3NmdWxseSBjaGFuZ2VkIG1vZGVcIjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG91dHB1dCA9IFwiV3JvbmcgbnVtYmVyIG9mIGFyZ3VtZW50cyBmb3IgbW9kZSBjb21tYW5kXCI7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChjb21tYW5kID09IFwibG9hZF9maWxlXCIpIHtcbiAgICAgIC8vVE9ETyBIQU5ETEUgSEVBREVSXG4gICAgICBpZiAoc3BsaXR0ZWQubGVuZ3RoID09IDIpIHtcbiAgICAgICAgdmFyIGZpbGVwYXRoID0gc3BsaXR0ZWRbMV07XG4gICAgICAgIGlmIChmaWxlcGF0aCBpbiBkYXRhKSB7XG4gICAgICAgICAgb3V0cHV0ID0gXCJGaWxlIHN1Y2Nlc3NmdWxseSBsb2FkZWRcIjtcbiAgICAgICAgICBjb25zb2xlLmxvZyhmaWxlcGF0aCk7XG4gICAgICAgICAgc2V0bG9hZGVkRmlsZXBhdGgoZmlsZXBhdGgpO1xuICAgICAgICAgIHNldEhhc0xvYWRlZCh0cnVlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvdXRwdXQgPSBcIkZpbGUgbm90IGZvdW5kIGluIGRpcmVjdG9yeVwiO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvdXRwdXQgPSBcIldyb25nIG51bWJlciBvZiBhcmd1bWVudHMgZm9yIGxvYWQgY29tbWFuZFwiO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PSBcInZpZXdcIikge1xuICAgICAgaWYgKGhhc0xvYWRlZCkge1xuICAgICAgICBpZiAoc3BsaXR0ZWQubGVuZ3RoID09IDEpIHtcbiAgICAgICAgICBvdXRwdXQgPVxuICAgICAgICAgICAgbG9hZGVkRmlsZXBhdGggaW4gZGF0YVxuICAgICAgICAgICAgICA/IGRhdGFbbG9hZGVkRmlsZXBhdGhdXG4gICAgICAgICAgICAgIDogXCJGaWxlIG5vdCBmb3VuZCBpbiBkaXJlY3RvcnlcIjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvdXRwdXQgPSBcIldyb25nIG51bWJlciBvZiBhcmd1bWVudHMgZm9yIHZpZXcgY29tbWFuZFwiO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvdXRwdXQgPSBcIkNhbm5vdCBjYWxsIHZpZXcgYmVmb3JlIGxvYWRcIjtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNvbW1hbmQgPT0gXCJzZWFyY2hcIikge1xuICAgICAgaWYgKGhhc0xvYWRlZCkge1xuICAgICAgICBpZiAoc3BsaXR0ZWQubGVuZ3RoID09IDMpIHtcbiAgICAgICAgICAvLyBIT1cgVE8gREVBTCBXSVRIIFNQQUNFUyBJTiBJTlBVVFxuICAgICAgICAgIHZhciBjb2x1bW4gPSBzcGxpdHRlZFsxXTtcbiAgICAgICAgICB2YXIgdmFsdWUgPSBzcGxpdHRlZFsyXTtcbiAgICAgICAgICB2YXIga2V5ID0gW2NvbHVtbiwgdmFsdWVdO1xuXG4gICAgICAgICAgaWYgKGxvYWRlZEZpbGVwYXRoIGluIHNlYXJjaERhdGEpIHtcbiAgICAgICAgICAgIHZhciBmaWxlcGF0aF9jb21tYW5kcyA9IHNlYXJjaERhdGFbbG9hZGVkRmlsZXBhdGhdO1xuICAgICAgICAgICAgb3V0cHV0ID1cbiAgICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoa2V5KSBpbiBmaWxlcGF0aF9jb21tYW5kc1xuICAgICAgICAgICAgICAgID8gZmlsZXBhdGhfY29tbWFuZHNbSlNPTi5zdHJpbmdpZnkoa2V5KV1cbiAgICAgICAgICAgICAgICA6IFwiQ29tbWFuZCBkb2VzIG5vdCBleGlzdCBpbiBtb2NrZWQgc2VhcmNoIGRhdGFcIjtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgb3V0cHV0ID0gXCJGaWxlIG5vdCBmb3VuZCBpbiBkaXJlY3RvcnlcIjtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb3V0cHV0ID0gXCJXcm9uZyBudW1iZXIgb2YgYXJndW1lbnRzIGZvciBzZWFyY2ggY29tbWFuZFwiO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvdXRwdXQgPSBcIkNhbm5vdCBjYWxsIHNlYXJjaCBiZWZvcmUgbG9hZFwiO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBvdXRwdXQgPSBcIk5vdCBhIHZhbGlkIGNvbW1hbmRcIjtcbiAgICB9XG5cbiAgICBpZiAodHlwZW9mIG91dHB1dCA9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBvdXRwdXQgPSBcIk5vdCBhIHZhbGlkIGNvbW1hbmRcIjtcbiAgICB9XG5cbiAgICBwcm9wcy5zZXRIaXN0b3J5KFsuLi5wcm9wcy5oaXN0b3J5LCBbY29tbWFuZFN0cmluZywgb3V0cHV0LCBwcm9wcy5tb2RlXV0pO1xuXG4gICAgc2V0Q291bnQoY291bnQgKyAxKTtcblxuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG4gIH1cbiAgLyoqXG4gICAqIFdlIHN1Z2dlc3QgYnJlYWtpbmcgZG93biB0aGlzIGNvbXBvbmVudCBpbnRvIHNtYWxsZXIgY29tcG9uZW50cywgdGhpbmsgYWJvdXQgdGhlIGluZGl2aWR1YWwgcGllY2VzXG4gICAqIG9mIHRoZSBSRVBMIGFuZCBob3cgdGhleSBjb25uZWN0IHRvIGVhY2ggb3RoZXIuLi5cbiAgICovXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCI+XG4gICAgICB7LyogVGhpcyBpcyBhIGNvbW1lbnQgd2l0aGluIHRoZSBKU1guIE5vdGljZSB0aGF0IGl0J3MgYSBUeXBlU2NyaXB0IGNvbW1lbnQgd3JhcHBlZCBpblxuICAgICAgICAgICAgYnJhY2VzLCBzbyB0aGF0IFJlYWN0IGtub3dzIGl0IHNob3VsZCBiZSBpbnRlcnByZXRlZCBhcyBUeXBlU2NyaXB0ICovfVxuICAgICAgey8qIEkgb3B0ZWQgdG8gdXNlIHRoaXMgSFRNTCB0YWc7IHlvdSBkb24ndCBuZWVkIHRvLiBJdCBzdHJ1Y3R1cmVzIG11bHRpcGxlIGlucHV0IGZpZWxkc1xuICAgICAgICAgICAgaW50byBhIHNpbmdsZSB1bml0LCB3aGljaCBtYWtlcyBpdCBlYXNpZXIgZm9yIHNjcmVlbnJlYWRlcnMgdG8gbmF2aWdhdGUuICovfVxuICAgICAgPGZpZWxkc2V0PlxuICAgICAgICA8bGVnZW5kPkVudGVyIGEgY29tbWFuZDo8L2xlZ2VuZD5cbiAgICAgICAgPENvbnRyb2xsZWRJbnB1dFxuICAgICAgICAgIHZhbHVlPXtjb21tYW5kU3RyaW5nfVxuICAgICAgICAgIHNldFZhbHVlPXtzZXRDb21tYW5kU3RyaW5nfVxuICAgICAgICAgIGFyaWFMYWJlbD17XCJDb21tYW5kIGlucHV0XCJ9XG4gICAgICAgIC8+XG4gICAgICA8L2ZpZWxkc2V0PlxuICAgICAgey8qIFRPRE86IEN1cnJlbnRseSB0aGlzIGJ1dHRvbiBqdXN0IGNvdW50cyB1cCwgY2FuIHdlIG1ha2UgaXQgcHVzaCB0aGUgY29udGVudHMgb2YgdGhlIGlucHV0IGJveCB0byB0aGUgaGlzdG9yeT8qL31cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpfT5TdWJtaXQ8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzLzIxa2Vubi9EZXNrdG9wL2NzMDMyMC9tb2NrLXRuZ2FtcHJhLXdjaHl1bi9zcmMvY29tcG9uZW50cy9SRVBMSW5wdXQudHN4In0=