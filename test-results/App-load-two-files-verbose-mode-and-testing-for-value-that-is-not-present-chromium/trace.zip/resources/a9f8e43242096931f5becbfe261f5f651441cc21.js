import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=f35b47c0"; const useState = __vite__cjsImport3_react["useState"];
import "/src/styles/main.css";
import { REPLHistory } from "/src/components/REPLHistory.tsx";
import { REPLInput } from "/src/components/REPLInput.tsx";
export default function REPL() {
  _s();
  const [history, setHistory] = useState([]);
  const [mode, setMode] = useState("brief");
  const [hasHeader, setHasHeader] = useState(true);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { history, mode }, void 0, false, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPLInput, { history, setHistory, mode, setMode }, void 0, false, {
      fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
}
_s(REPL, "CMbW7+WU5dKujAzUV426mMLe69o=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5CTixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBTztBQUNQLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxpQkFBaUI7QUFPMUIsd0JBQXdCQyxPQUFPO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlOLFNBRTVCLEVBQUU7QUFDSixRQUFNLENBQUNPLE1BQU1DLE9BQU8sSUFBSVIsU0FBaUIsT0FBTztBQUNoRCxRQUFNLENBQUNTLFdBQVdDLFlBQVksSUFBSVYsU0FBa0IsSUFBSTtBQUV4RCxTQUNFLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsMkJBQUMsZUFBWSxTQUFrQixRQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDO0FBQUEsSUFDMUMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUk7QUFBQSxJQUNKLHVCQUFDLGFBQ0MsU0FDQSxZQUNBLE1BQ0EsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSW1CO0FBQUEsT0FQckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBRUo7QUFBQ0ksR0FuQnVCRCxNQUFJO0FBQUFRLEtBQUpSO0FBQUksSUFBQVE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiUkVQTEhpc3RvcnkiLCJSRVBMSW5wdXQiLCJSRVBMIiwiX3MiLCJoaXN0b3J5Iiwic2V0SGlzdG9yeSIsIm1vZGUiLCJzZXRNb2RlIiwiaGFzSGVhZGVyIiwic2V0SGFzSGVhZGVyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBSRVBMSGlzdG9yeSB9IGZyb20gXCIuL1JFUExIaXN0b3J5XCI7XG5pbXBvcnQgeyBSRVBMSW5wdXQgfSBmcm9tIFwiLi9SRVBMSW5wdXRcIjtcblxuLyoqXG4gKiBJbiBSRVBMLCB3ZSBhcmUgdHJ5aW5nIHRvIGFkZCBzb21lIGtpbmQgb2Ygc2hhcmVkIHN0YXRlIHRoYXQgaG9sZHMgYWxsIHRoZSBjb21tYW5kcyBzdWJtaXR0ZWQuIFxuICogVGhpcyBjbGFzcyBpcyBhbHNvIHdoZXJlIG91ciBSRVBMIGhpc3RvcnkgZ29lcy4gXG4gKi9cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUkVQTCgpIHtcbiAgY29uc3QgW2hpc3RvcnksIHNldEhpc3RvcnldID0gdXNlU3RhdGU8XG4gICAgW3N0cmluZywgc3RyaW5nW11bXSB8IHN0cmluZywgc3RyaW5nXVtdXG4gID4oW10pO1xuICBjb25zdCBbbW9kZSwgc2V0TW9kZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiYnJpZWZcIik7XG4gIGNvbnN0IFtoYXNIZWFkZXIsIHNldEhhc0hlYWRlcl0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbFwiPlxuICAgICAgPFJFUExIaXN0b3J5IGhpc3Rvcnk9e2hpc3Rvcnl9IG1vZGU9e21vZGV9IC8+XG4gICAgICA8aHI+PC9ocj5cbiAgICAgIDxSRVBMSW5wdXRcbiAgICAgICAgaGlzdG9yeT17aGlzdG9yeX1cbiAgICAgICAgc2V0SGlzdG9yeT17c2V0SGlzdG9yeX1cbiAgICAgICAgbW9kZT17bW9kZX1cbiAgICAgICAgc2V0TW9kZT17c2V0TW9kZX1cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy8yMWtlbm4vRGVza3RvcC9jczAzMjAvbW9jay10bmdhbXByYS13Y2h5dW4vc3JjL2NvbXBvbmVudHMvUkVQTC50c3gifQ==