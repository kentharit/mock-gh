import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
import { OutputBox } from "/src/components/OutputBox.tsx";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: props.history.map((historyTuple, index) => /* @__PURE__ */ jsxDEV(OutputBox, { command: historyTuple[0], data: historyTuple[1], mode: historyTuple[2] }, void 0, false, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLHistory.tsx",
    lineNumber: 9,
    columnNumber: 51
  }, this)) }, void 0, false, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLHistory.tsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1E7QUFYUixPQUFPLG9CQUFvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQixTQUFTQSxpQkFBaUI7QUFNbkIsZ0JBQVNDLFlBQVlDLE9BQXlCO0FBQ25ELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGdCQUNaQSxnQkFBTUMsUUFBUUMsSUFBSSxDQUFDQyxjQUFjQyxVQUNoQyx1QkFBQyxhQUNDLFNBQVNELGFBQWEsQ0FBQyxHQUN2QixNQUFNQSxhQUFhLENBQUMsR0FDcEIsTUFBTUEsYUFBYSxDQUFDLEtBSHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHd0IsQ0FFekIsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFSjtBQUFDRSxLQVplTjtBQUFXLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJPdXRwdXRCb3giLCJSRVBMSGlzdG9yeSIsInByb3BzIiwiaGlzdG9yeSIsIm1hcCIsImhpc3RvcnlUdXBsZSIsImluZGV4IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSGlzdG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBPdXRwdXRCb3ggfSBmcm9tIFwiLi9PdXRwdXRCb3hcIjtcblxuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHMge1xuICBoaXN0b3J5OiBbc3RyaW5nLCBzdHJpbmdbXVtdIHwgc3RyaW5nLCBzdHJpbmddW107XG4gIG1vZGU6IHN0cmluZztcbn1cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSGlzdG9yeShwcm9wczogUkVQTEhpc3RvcnlQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbC1oaXN0b3J5XCI+XG4gICAgICB7cHJvcHMuaGlzdG9yeS5tYXAoKGhpc3RvcnlUdXBsZSwgaW5kZXgpID0+IChcbiAgICAgICAgPE91dHB1dEJveFxuICAgICAgICAgIGNvbW1hbmQ9e2hpc3RvcnlUdXBsZVswXX1cbiAgICAgICAgICBkYXRhPXtoaXN0b3J5VHVwbGVbMV19XG4gICAgICAgICAgbW9kZT17aGlzdG9yeVR1cGxlWzJdfVxuICAgICAgICAvPlxuICAgICAgKSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy8yMWtlbm4vRGVza3RvcC9jczAzMjAvbW9jay10bmdhbXByYS13Y2h5dW4vc3JjL2NvbXBvbmVudHMvUkVQTEhpc3RvcnkudHN4In0=