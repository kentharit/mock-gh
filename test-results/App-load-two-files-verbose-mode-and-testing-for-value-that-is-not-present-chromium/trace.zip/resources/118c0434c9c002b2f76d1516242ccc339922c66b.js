import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function ControlledInput({
  value,
  setValue,
  ariaLabel
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value, placeholder: "Enter command here!", onChange: (ev) => setValue(ev.target.value), "aria-label": ariaLabel }, void 0, false, {
    fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/ControlledInput.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JJO0FBcEJKLE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBY3BCLGdCQUFTQSxnQkFBZ0I7QUFBQSxFQUM5QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDb0IsR0FBRztBQUN2QixTQUNFLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLFdBQVUsb0JBQ1YsT0FDQSxhQUFZLHVCQUNaLFVBQVdDLFFBQU9GLFNBQVNFLEdBQUdDLE9BQU9KLEtBQUssR0FDMUMsY0FBWUUsYUFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0M7QUFFTDtBQUFDRyxLQWZlTjtBQUFlLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDb250cm9sbGVkSW5wdXQiLCJ2YWx1ZSIsInNldFZhbHVlIiwiYXJpYUxhYmVsIiwiZXYiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnRyb2xsZWRJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24gfSBmcm9tIFwicmVhY3RcIjtcblxuLy8gUmVtZW1iZXIgdGhhdCBwYXJhbWV0ZXIgbmFtZXMgZG9uJ3QgbmVjZXNzYXJpbHkgbmVlZCB0byBvdmVybGFwO1xuLy8gSSBjb3VsZCB1c2UgZGlmZmVyZW50IHZhcmlhYmxlIG5hbWVzIGluIHRoZSBhY3R1YWwgZnVuY3Rpb24uXG5pbnRlcmZhY2UgQ29udHJvbGxlZElucHV0UHJvcHMge1xuICB2YWx1ZTogc3RyaW5nO1xuICAvLyBUaGlzIHR5cGUgY29tZXMgZnJvbSBSZWFjdCtUeXBlU2NyaXB0LiBWU0NvZGUgY2FuIHN1Z2dlc3QgdGhlc2UuXG4gIC8vICAgQ29uY3JldGVseSwgdGhpcyBtZWFucyBcImEgZnVuY3Rpb24gdGhhdCBzZXRzIGEgc3RhdGUgY29udGFpbmluZyBhIHN0cmluZ1wiXG4gIHNldFZhbHVlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PjtcbiAgYXJpYUxhYmVsOiBzdHJpbmc7XG59XG5cbi8qKiBUaGlzIGNsYXNzIGluIHRlcm1zIG9mIGRlZmluaXRpb25zIG1lYW5zIGEgZnVuY3Rpb24gdGhhdCBzZXRzIGEgc3RhdGUgY29udGFpbmluZyBhIHN0cmluZy4gICovXG5leHBvcnQgZnVuY3Rpb24gQ29udHJvbGxlZElucHV0KHtcbiAgdmFsdWUsXG4gIHNldFZhbHVlLFxuICBhcmlhTGFiZWwsXG59OiBDb250cm9sbGVkSW5wdXRQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxpbnB1dFxuICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgY2xhc3NOYW1lPVwicmVwbC1jb21tYW5kLWJveFwiXG4gICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGNvbW1hbmQgaGVyZSFcIlxuICAgICAgb25DaGFuZ2U9eyhldikgPT4gc2V0VmFsdWUoZXYudGFyZ2V0LnZhbHVlKX1cbiAgICAgIGFyaWEtbGFiZWw9e2FyaWFMYWJlbH1cbiAgICA+PC9pbnB1dD5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzLzIxa2Vubi9EZXNrdG9wL2NzMDMyMC9tb2NrLXRuZ2FtcHJhLXdjaHl1bi9zcmMvY29tcG9uZW50cy9Db250cm9sbGVkSW5wdXQudHN4In0=