import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/OutputBox.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f35b47c0"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function OutputBox({
  command,
  data,
  mode
}) {
  if (mode === "brief") {
    if (Array.isArray(data)) {
      return /* @__PURE__ */ jsxDEV("div", { className: "bordered-div", children: /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tbody", { children: data.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 33,
        columnNumber: 49
      }, this)) }, rowIndex, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 32,
        columnNumber: 44
      }, this)) }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 31,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 30,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 29,
        columnNumber: 14
      }, this);
    } else {
      return /* @__PURE__ */ jsxDEV("div", { className: "bordered-div", children: /* @__PURE__ */ jsxDEV("p", { children: [
        " ",
        data,
        " "
      ] }, void 0, true, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 40,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 39,
        columnNumber: 14
      }, this);
    }
  } else {
    if (Array.isArray(data)) {
      return /* @__PURE__ */ jsxDEV("div", { className: "bordered-div", children: [
        /* @__PURE__ */ jsxDEV("p", { children: [
          " Command: ",
          command,
          " "
        ] }, void 0, true, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 46,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: " Output: " }, void 0, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 47,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tbody", { children: data.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 51,
          columnNumber: 49
        }, this)) }, rowIndex, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 50,
          columnNumber: 44
        }, this)) }, void 0, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 49,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 48,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 45,
        columnNumber: 14
      }, this);
    } else {
      return /* @__PURE__ */ jsxDEV("div", { className: "bordered-div", children: [
        /* @__PURE__ */ jsxDEV("p", { children: [
          " Command: ",
          command,
          " "
        ] }, void 0, true, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 58,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          " Output: ",
          data,
          " "
        ] }, void 0, true, {
          fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
          lineNumber: 59,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx",
        lineNumber: 57,
        columnNumber: 14
      }, this);
    }
  }
}
_c = OutputBox;
var _c;
$RefreshReg$(_c, "OutputBox");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/21kenn/Desktop/cs0320/mock-tngampra-wchyun/src/components/OutputBox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JvQjtBQS9CcEIsT0FBTyxvQkFBb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFrQnBCLGdCQUFTQSxVQUFVO0FBQUEsRUFBRUM7QUFBQUEsRUFBU0M7QUFBQUEsRUFBTUM7QUFBcUIsR0FBRztBQUVqRSxNQUFJQSxTQUFTLFNBQVM7QUFDcEIsUUFBSUMsTUFBTUMsUUFBUUgsSUFBSSxHQUFHO0FBR3ZCLGFBQ0UsdUJBQUMsU0FBSSxXQUFVLGdCQUNiLGlDQUFDLFdBQ0MsaUNBQUMsV0FDRUEsZUFBS0ksSUFBSSxDQUFDQyxLQUFLQyxhQUNkLHVCQUFDLFFBQ0VELGNBQUlELElBQUksQ0FBQ0csTUFBTUMsY0FDZCx1QkFBQyxRQUFvQkQsa0JBQVpDLFdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQixDQUMzQixLQUhNRixVQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQSxDQUNELEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsSUFFSixPQUFPO0FBQ0wsYUFDRSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2IsaUNBQUMsT0FBRTtBQUFBO0FBQUEsUUFBRU47QUFBQUEsUUFBSztBQUFBLFdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXLEtBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFFSjtBQUFBLEVBQ0YsT0FBTztBQUNMLFFBQUlFLE1BQU1DLFFBQVFILElBQUksR0FBRztBQUN2QixhQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLE9BQUU7QUFBQTtBQUFBLFVBQVdEO0FBQUFBLFVBQVE7QUFBQSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsUUFDdkIsdUJBQUMsT0FBRSx5QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVk7QUFBQSxRQUNaLHVCQUFDLFdBQ0MsaUNBQUMsV0FDRUMsZUFBS0ksSUFBSSxDQUFDQyxLQUFLQyxhQUNkLHVCQUFDLFFBQ0VELGNBQUlELElBQUksQ0FBQ0csTUFBTUMsY0FDZCx1QkFBQyxRQUFvQkQsa0JBQVpDLFdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQixDQUMzQixLQUhNRixVQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxDQUNELEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxJQUVKLE9BQU87QUFDTCxhQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLE9BQUU7QUFBQTtBQUFBLFVBQVdQO0FBQUFBLFVBQVE7QUFBQSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsUUFDdkIsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBVUM7QUFBQUEsVUFBSztBQUFBLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxXQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxJQUVKO0FBQUEsRUFDRjtBQUNGO0FBQUNTLEtBeERlWDtBQUFTLElBQUFXO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJPdXRwdXRCb3giLCJjb21tYW5kIiwiZGF0YSIsIm1vZGUiLCJBcnJheSIsImlzQXJyYXkiLCJtYXAiLCJyb3ciLCJyb3dJbmRleCIsImNlbGwiLCJjZWxsSW5kZXgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk91dHB1dEJveC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24gfSBmcm9tIFwicmVhY3RcIjtcblxuLy8gUmVtZW1iZXIgdGhhdCBwYXJhbWV0ZXIgbmFtZXMgZG9uJ3QgbmVjZXNzYXJpbHkgbmVlZCB0byBvdmVybGFwO1xuLy8gSSBjb3VsZCB1c2UgZGlmZmVyZW50IHZhcmlhYmxlIG5hbWVzIGluIHRoZSBhY3R1YWwgZnVuY3Rpb24uXG5pbnRlcmZhY2UgT3V0cHV0Qm94UHJvcHMge1xuICBjb21tYW5kOiBzdHJpbmc7XG4gIGRhdGE6IHN0cmluZ1tdW10gfCBzdHJpbmc7XG4gIG1vZGU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBUaGUgb3V0cHV0IGJveCBkaXNwbGF5cyBkaWZmZXJlbnRseSBiYXNlZCBvbiB3aGF0IG1vZGUgdGhlIHVzZXIgaG9wZXMgdG8gYmUgcGFydCBvZi4gXG4gKiBJbiB0aGUg4oCcYnJpZWbigJ0gb3V0cHV0LCBpdCB3aWxsIGp1c3QgZGlzcGxheSB0aGUgcmVzdWx0IG9mIHJ1bm5pbmcgdGhlIGNvbW1hbmQuIFxuICogSW4gdGhlIHZlcmJvc2UgbW9kZSwgaXQgd2lsbCBkaXNwbGF5IGJvdGggdGhlIGNvbW1hbmQgdGV4dCBhbmQgdGhlIHJlc3VsdCBvZiBydW5uaW5nIHRoZSBjb21tYW5kLiAgXG4gKiBAcGFyYW0gT3V0cHV0Qm94UHJvcHM6IGNvbnRhaW5zIHRoZSBjb21tYW5kLCBkYXRhLCBhbmQgbW9kZSBjb3JyZXNwb25kaW5nIHRvIGVhY2ggY29tbWFuZCBjYWxsLiBcbiAqIEByZXR1cm5zIGRpdiB0aGF0IGNvbnRhaW5zIGEgdGFibGUgYW5kIHRleHQgb3Igb25seSB0ZXh0IGRlcGVuZGluZyBvbiBtb2RlIGFuZCBjb21tYW5kLlxuICovXG5leHBvcnQgZnVuY3Rpb24gT3V0cHV0Qm94KHsgY29tbWFuZCwgZGF0YSwgbW9kZSB9OiBPdXRwdXRCb3hQcm9wcykge1xuICAvLyAgIHJldHVybiBtb2RlID09PSBcImJyaWVmXCIgPyA8cD4ge2NvbW1hbmR9IDwvcD4gOiA8cD4gbm8gY29tbWFuZCA8L3A+O1xuICBpZiAobW9kZSA9PT0gXCJicmllZlwiKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoZGF0YSkpIHtcbiAgICAgIC8vIENoZWNrIGlmIGRhdGEgaXMgYSBsaXN0IG9mIGxpc3Qgb2Ygc3RyaW5ncyAoc3RyaW5nW11bXSlcbiAgICAgIC8vIElmIHNvLCBnZW5lcmF0ZSBhbiBIVE1MIHRhYmxlXG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlcmVkLWRpdlwiPlxuICAgICAgICAgIDx0YWJsZT5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAge2RhdGEubWFwKChyb3csIHJvd0luZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgPHRyIGtleT17cm93SW5kZXh9PlxuICAgICAgICAgICAgICAgICAge3Jvdy5tYXAoKGNlbGwsIGNlbGxJbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8dGQga2V5PXtjZWxsSW5kZXh9PntjZWxsfTwvdGQ+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlcmVkLWRpdlwiPlxuICAgICAgICAgIDxwPiB7ZGF0YX0gPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlcmVkLWRpdlwiPlxuICAgICAgICAgIDxwPiBDb21tYW5kOiB7Y29tbWFuZH0gPC9wPlxuICAgICAgICAgIDxwPiBPdXRwdXQ6IDwvcD5cbiAgICAgICAgICA8dGFibGU+XG4gICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgIHtkYXRhLm1hcCgocm93LCByb3dJbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgIDx0ciBrZXk9e3Jvd0luZGV4fT5cbiAgICAgICAgICAgICAgICAgIHtyb3cubWFwKChjZWxsLCBjZWxsSW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHRkIGtleT17Y2VsbEluZGV4fT57Y2VsbH08L3RkPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXJlZC1kaXZcIj5cbiAgICAgICAgICA8cD4gQ29tbWFuZDoge2NvbW1hbmR9IDwvcD5cbiAgICAgICAgICA8cD4gT3V0cHV0OiB7ZGF0YX0gPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICk7XG4gICAgfVxuICB9XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy8yMWtlbm4vRGVza3RvcC9jczAzMjAvbW9jay10bmdhbXByYS13Y2h5dW4vc3JjL2NvbXBvbmVudHMvT3V0cHV0Qm94LnRzeCJ9